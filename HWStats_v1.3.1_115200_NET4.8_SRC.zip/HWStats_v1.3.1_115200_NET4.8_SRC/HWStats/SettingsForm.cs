using System;
using System.Drawing;
using System.Windows.Forms;

namespace HWStats
{
    public partial class SettingsForm : Form
    {
        private readonly SerialDeviceManager _deviceManager; // To send the * Config string

        // --- UI Controls ---

        // 1. Connection & Basic
        private ComboBox cboBaudRate;
        private NumericUpDown numRefreshInterval;
        private TextBox txtCustomMessage;

        // 2. Custom Names
        private TextBox txtCustomCpu, txtCustomGpu;

        // 3. Auto Game Mode
        private CheckBox chkAutoGame;
        private NumericUpDown numGpuThreshold;
        private TextBox txtExceptions;

        // 4. Display Modes
        private RadioButton rbNormal, rbGaming, rbFocus, rbNerd, rbGif;

        // 5. Offline Config (Device Memory)
        private TextBox txtCity, txtLat, txtLon, txtSSID, txtPass, txtAPI, txtOffset;

        // 6. Checkbox for 12hr/24hr toggle
        private CheckBox chk12Hour;

        // Footer Buttons
        private Button btnSave;
        private Button btnCancel;

        // Constructor
        public SettingsForm(SerialDeviceManager deviceManager)
        {
            _deviceManager = deviceManager;
            InitializeComponentCustom();
            LoadCurrentSettings();
        }

        private void LoadCurrentSettings()
        {
            // --- 1. Basic ---
            string currentBaud = SettingsManager.CurrentSettings.BaudRate.ToString();
            if (cboBaudRate.Items.Contains(currentBaud))
                cboBaudRate.SelectedItem = currentBaud;
            else
                cboBaudRate.Text = "115200";

            numRefreshInterval.Value = Math.Max(100, SettingsManager.CurrentSettings.RefreshInterval);
            txtCustomMessage.Text = SettingsManager.CurrentSettings.CustomMessage;

            // --- 2. Custom Names ---
            txtCustomCpu.Text = SettingsManager.CurrentSettings.CustomCpuName;
            txtCustomGpu.Text = SettingsManager.CurrentSettings.CustomGpuName;

            // --- 3. Auto Game Mode ---
            chkAutoGame.Checked = SettingsManager.CurrentSettings.AutoGameModeEnabled;
            numGpuThreshold.Value = SettingsManager.CurrentSettings.AutoGpuThreshold;
            txtExceptions.Text = SettingsManager.CurrentSettings.ExceptionList;

            // --- 4. Display Mode ---
            int mode = SettingsManager.CurrentSettings.DisplayMode;
            switch (mode)
            {
                case 1: rbGaming.Checked = true; break;
                case 2: rbFocus.Checked = true; break;
                case 3: rbNerd.Checked = true; break;
                case 4: rbGif.Checked = true; break;
                default: rbNormal.Checked = true; break;
            }

            // --- 5. Offline Config ---
            txtCity.Text = SettingsManager.CurrentSettings.City;
            txtLat.Text = SettingsManager.CurrentSettings.Latitude;
            txtLon.Text = SettingsManager.CurrentSettings.Longitude;
            txtSSID.Text = SettingsManager.CurrentSettings.WifiSSID;
            txtPass.Text = SettingsManager.CurrentSettings.WifiPass;
            txtAPI.Text = SettingsManager.CurrentSettings.ApiKey;
            txtOffset.Text = SettingsManager.CurrentSettings.TimeOffset;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // 1. Basic
            if (int.TryParse(cboBaudRate.Text, out int baud))
                SettingsManager.CurrentSettings.BaudRate = baud;

            SettingsManager.CurrentSettings.RefreshInterval = (int)numRefreshInterval.Value;
            SettingsManager.CurrentSettings.CustomMessage = txtCustomMessage.Text;

            // 2. Custom Names
            SettingsManager.CurrentSettings.CustomCpuName = txtCustomCpu.Text;
            SettingsManager.CurrentSettings.CustomGpuName = txtCustomGpu.Text;

            // 3. Auto Game Mode
            SettingsManager.CurrentSettings.AutoGameModeEnabled = chkAutoGame.Checked;
            SettingsManager.CurrentSettings.AutoGpuThreshold = (int)numGpuThreshold.Value;
            SettingsManager.CurrentSettings.ExceptionList = txtExceptions.Text.ToLower();

            // 4. Display Mode
            int mode = 0;
            if (rbGaming.Checked) mode = 1;
            else if (rbFocus.Checked) mode = 2;
            else if (rbNerd.Checked) mode = 3;
            else if (rbGif.Checked) mode = 4;
            SettingsManager.CurrentSettings.DisplayMode = mode;

            // 5. Offline Config (PC Storage)
            SettingsManager.CurrentSettings.City = txtCity.Text;
            SettingsManager.CurrentSettings.Latitude = txtLat.Text;
            SettingsManager.CurrentSettings.Longitude = txtLon.Text;
            SettingsManager.CurrentSettings.WifiSSID = txtSSID.Text;
            SettingsManager.CurrentSettings.WifiPass = txtPass.Text;
            SettingsManager.CurrentSettings.ApiKey = txtAPI.Text;
            SettingsManager.CurrentSettings.TimeOffset = txtOffset.Text;

            // Write to Disk
            SettingsManager.Save();

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnFlashConfig_Click(object sender, EventArgs e)
        {
            if (_deviceManager == null || !_deviceManager.IsConnected)
            {
                MessageBox.Show("Device not connected! Please connect first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Determine 12h (1) or 24h (0) based on checkbox
            string is12h = chk12Hour.Checked ? "1" : "0";

            // Format: *offset;city;lat;lon;ssid;pass;api;12h
            string configData = $"*{txtOffset.Text};{txtCity.Text};{txtLat.Text};{txtLon.Text};{txtSSID.Text};{txtPass.Text};{txtAPI.Text};{is12h}";

            try
            {
                _deviceManager.SendData(configData);
                MessageBox.Show("Configuration Sent to Device!\n(Device will restart to apply settings)", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to send: {ex.Message}");
            }
        }

        private void btnAutoOffset_Click(object sender, EventArgs e)
        {
            long offset = (long)TimeZoneInfo.Local.GetUtcOffset(DateTime.Now).TotalSeconds;
            txtOffset.Text = offset.ToString();
        }

        private void InitializeComponentCustom()
        {
            this.Size = new Size(500, 850); 
            this.Text = "Settings & Device Config";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.AutoScroll = true;

            int x = 20;
            int y = 20;

            // --- Section 1: Basic Connection ---
            this.Controls.Add(new Label { Text = "Baud Rate:", Location = new Point(x, y), AutoSize = true });
            cboBaudRate = new ComboBox { Location = new Point(x + 100, y - 3), Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
            cboBaudRate.Items.AddRange(new object[] { "9600", "19200", "38400", "57600", "115200", "230400", "460800", "921600" });
            this.Controls.Add(cboBaudRate);

            y += 35;
            this.Controls.Add(new Label { Text = "Refresh (ms):", Location = new Point(x, y), AutoSize = true });
            numRefreshInterval = new NumericUpDown { Location = new Point(x + 100, y - 3), Width = 120, Minimum = 100, Maximum = 60000 };
            this.Controls.Add(numRefreshInterval);

            y += 35;
            this.Controls.Add(new Label { Text = "Custom Text:", Location = new Point(x, y), AutoSize = true });
            txtCustomMessage = new TextBox { Location = new Point(x + 100, y - 3), Width = 200 };
            this.Controls.Add(txtCustomMessage);

            // --- Section 2: Custom Names ---
            y += 45;
            GroupBox grpNames = new GroupBox { Text = "Custom Hardware Names", Location = new Point(x, y), Size = new Size(440, 90) };

            grpNames.Controls.Add(new Label { Text = "CPU Name:", Location = new Point(15, 25), AutoSize = true });
            txtCustomCpu = new TextBox { Location = new Point(90, 22), Width = 300 };
            grpNames.Controls.Add(txtCustomCpu);

            grpNames.Controls.Add(new Label { Text = "GPU Name:", Location = new Point(15, 55), AutoSize = true });
            txtCustomGpu = new TextBox { Location = new Point(90, 52), Width = 300 };
            grpNames.Controls.Add(txtCustomGpu);

            this.Controls.Add(grpNames);

            // --- Section 3: Auto Game Mode ---
            y += 100;
            GroupBox grpAuto = new GroupBox { Text = "Auto-Trigger Game Mode", Location = new Point(x, y), Size = new Size(440, 100) };

            chkAutoGame = new CheckBox { Text = "Enable Auto-Switching", Location = new Point(15, 20), AutoSize = true };
            grpAuto.Controls.Add(chkAutoGame);

            grpAuto.Controls.Add(new Label { Text = "Trigger if GPU >", Location = new Point(200, 22), AutoSize = true });
            numGpuThreshold = new NumericUpDown { Location = new Point(290, 20), Width = 50, Minimum = 1, Maximum = 99 };
            grpAuto.Controls.Add(numGpuThreshold);
            grpAuto.Controls.Add(new Label { Text = "%", Location = new Point(345, 22), AutoSize = true });

            grpAuto.Controls.Add(new Label { Text = "Exceptions (.exe file):", Location = new Point(15, 60), AutoSize = true });
            txtExceptions = new TextBox { Location = new Point(120, 58), Width = 300 };
            Label lblHint = new Label { Text = "(e.g., chrome, vlc, code)", Location = new Point(110, 80), ForeColor = Color.Gray, Font = new Font(this.Font.FontFamily, 7) };
            grpAuto.Controls.Add(txtExceptions);
            grpAuto.Controls.Add(lblHint);

            this.Controls.Add(grpAuto);

            // --- Section 4: Display Mode ---
            y += 110;
            GroupBox grpMode = new GroupBox { Text = "Manual Display Mode", Location = new Point(x, y), Size = new Size(440, 60) };

            rbNormal = new RadioButton { Text = "Normal", Location = new Point(10, 20), AutoSize = true };
            rbGaming = new RadioButton { Text = "Gaming", Location = new Point(80, 20), AutoSize = true };
            rbFocus = new RadioButton { Text = "Focus", Location = new Point(160, 20), AutoSize = true };
            rbNerd = new RadioButton { Text = "Nerd", Location = new Point(230, 20), AutoSize = true };
            rbGif = new RadioButton { Text = "GIF", Location = new Point(290, 20), AutoSize = true };

            grpMode.Controls.AddRange(new Control[] { rbNormal, rbGaming, rbFocus, rbNerd, rbGif });
            this.Controls.Add(grpMode);

            // --- Section 5: Offline Config ---
            y += 70;
            GroupBox grpConfig = new GroupBox { Text = "Device Offline Config (Weather/Clock)", Location = new Point(x, y), Size = new Size(440, 280) };

            int gx = 15, gy = 25;

            // City & Offset
            grpConfig.Controls.Add(new Label { Text = "City:", Location = new Point(gx, gy), AutoSize = true });
            txtCity = new TextBox { Location = new Point(gx + 60, gy - 3), Width = 120 };
            grpConfig.Controls.Add(txtCity);

            grpConfig.Controls.Add(new Label { Text = "TZ Offset:", Location = new Point(gx + 200, gy), AutoSize = true });
            txtOffset = new TextBox { Location = new Point(gx + 270, gy - 3), Width = 80 };
            grpConfig.Controls.Add(txtOffset);

            Button btnAutoTz = new Button { Text = "Auto", Location = new Point(gx + 360, gy - 5), Width = 50, Height = 23 };
            btnAutoTz.Click += btnAutoOffset_Click;
            grpConfig.Controls.Add(btnAutoTz);

            // Lat & Lon
            gy += 35;
            grpConfig.Controls.Add(new Label { Text = "Lat:", Location = new Point(gx, gy), AutoSize = true });
            txtLat = new TextBox { Location = new Point(gx + 60, gy - 3), Width = 120 };
            grpConfig.Controls.Add(txtLat);

            grpConfig.Controls.Add(new Label { Text = "Lon:", Location = new Point(gx + 200, gy), AutoSize = true });
            txtLon = new TextBox { Location = new Point(gx + 270, gy - 3), Width = 120 };
            grpConfig.Controls.Add(txtLon);

            // WiFi
            gy += 35;
            grpConfig.Controls.Add(new Label { Text = "WiFi SSID:", Location = new Point(gx, gy), AutoSize = true });
            txtSSID = new TextBox { Location = new Point(gx + 80, gy - 3), Width = 300 };
            grpConfig.Controls.Add(txtSSID);

            gy += 35;
            grpConfig.Controls.Add(new Label { Text = "WiFi Pass:", Location = new Point(gx, gy), AutoSize = true });
            txtPass = new TextBox { Location = new Point(gx + 80, gy - 3), Width = 300, PasswordChar = '*' };
            grpConfig.Controls.Add(txtPass);

            // API
            gy += 35;
            grpConfig.Controls.Add(new Label { Text = "API Key:", Location = new Point(gx, gy), AutoSize = true });
            txtAPI = new TextBox { Location = new Point(gx + 80, gy - 3), Width = 300, PasswordChar = '*' };
            grpConfig.Controls.Add(txtAPI);

            // 12-Hour Checkbox (NEW)
            gy += 35;
            chk12Hour = new CheckBox { Text = "Use 12-Hour Format (AM/PM)", Location = new Point(gx + 80, gy), AutoSize = true };
            grpConfig.Controls.Add(chk12Hour);

            // Flash Button
            gy += 35;
            Button btnFlash = new Button { Text = "Flash Settings to ESP32 (Writes to Memory)", Location = new Point(gx + 80, gy), Width = 300, BackColor = Color.LightBlue, Height = 30 };
            btnFlash.Click += btnFlashConfig_Click;
            grpConfig.Controls.Add(btnFlash);

            this.Controls.Add(grpConfig);

            // --- Footer Buttons ---
            y += 300;
            btnSave = new Button { Text = "Save Settings", Location = new Point(240, y), Width = 100, Height = 30, DialogResult = DialogResult.OK };
            btnSave.Click += btnSave_Click;

            btnCancel = new Button { Text = "Cancel", Location = new Point(360, y), Width = 100, Height = 30, DialogResult = DialogResult.Cancel };
            btnCancel.Click += (s, ev) => { this.Close(); };

            this.Controls.Add(btnSave);
            this.Controls.Add(btnCancel);

            // Final Resize
            this.ClientSize = new Size(480, y + 50);
        }
    }
}