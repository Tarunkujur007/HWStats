using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;

public static class GameDetector
{
    // --- Windows API Imports ---
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    // --- Core Function 1: Get Process Name (for Exception List) ---
    public static string GetForegroundProcessName()
    {
        try
        {
            IntPtr hWnd = GetForegroundWindow();
            if (hWnd == IntPtr.Zero) return "";

            GetWindowThreadProcessId(hWnd, out uint procId);
            using (Process proc = Process.GetProcessById((int)procId))
            {
                return proc.ProcessName.ToLower();
            }
        }
        catch { return ""; }
    }

    // --- Core Function 2: Get Friendly Game Name from PID ---
    public static string GetGameNameFromPid(int pid)
    {
        try
        {
            using (Process p = Process.GetProcessById(pid))
            {
                // 1. Try to get the Window Title (usually "Cyberpunk 2077")
                string title = p.MainWindowTitle;

                // 2. Fallback: If title is empty, use Process Name
                if (string.IsNullOrWhiteSpace(title))
                {
                    title = p.ProcessName;
                }

                return CleanGameName(title);
            }
        }
        catch
        {
            return "";
        }
    }

    // --- IMPROVED CLEANUP LOGIC ---
    private static string CleanGameName(string input)
    {
        if (string.IsNullOrEmpty(input)) return "";

        string cleaned = input;

        // 1. Remove Trademark (�), Registered (�), Copyright (�)
        cleaned = Regex.Replace(cleaned, @"[���]", "");

        // 2. Remove text in parentheses (e.g. "(64-bit)", "(DX11)")
        cleaned = Regex.Replace(cleaned, @"\s*\(.*?\)", "");

        // 3. Remove text in square brackets
        cleaned = Regex.Replace(cleaned, @"\s*\[.*?\]", "");

        // 4. Remove Version Numbers and Build IDs at the end
        // Logic: Look for space + (v+digit OR build OR version) + everything after it
        cleaned = Regex.Replace(cleaned, @"\s+(v\d+|build|version).*$", "", RegexOptions.IgnoreCase);

        // 5. Remove any leftover non-standard characters (Optional safety net)
        // This removes anything that isn't a letter, number, space, or standard punctuation
        // Note: We keep ':' for "Terminator: Resistance" and '-' for "Half-Life"
        // cleaned = Regex.Replace(cleaned, @"[^\w\s\-\:\']", ""); 

        // 6. Cleanup extra double spaces created by removals
        cleaned = Regex.Replace(cleaned, @"\s{2,}", " ");

        return cleaned.Trim();
    }
}