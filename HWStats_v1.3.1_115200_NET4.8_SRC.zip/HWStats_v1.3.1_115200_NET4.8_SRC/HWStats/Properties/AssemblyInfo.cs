﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HWStats")]
[assembly: AssemblyDescription("")]

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("AAA Labs")]
[assembly: AssemblyProduct("HWStats")]
[assembly: AssemblyCopyright("Copyright © 2026 AAA Labs")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("6719b22b-c5ec-498f-9d1a-328f39fff467")]
[assembly: AssemblyVersion("1.3.1")]
[assembly: AssemblyFileVersion("1.3.1")]
