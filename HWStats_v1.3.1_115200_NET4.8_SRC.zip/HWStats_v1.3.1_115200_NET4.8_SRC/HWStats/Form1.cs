using HWStats.Properties;
using Microsoft.Win32.TaskScheduler;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HWStats
{
    public partial class Form1 : Form
    {
        private enum AppStatus { Disconnected, Searching, Connected, Error }

        private readonly SerialDeviceManager _deviceManager = new SerialDeviceManager();
        private readonly HardwareMonitor _hardwareMonitor = new HardwareMonitor();
        private readonly StatsProvider _statsProvider;
        private CancellationTokenSource _connectionCts;
        private System.Threading.Tasks.Task _connectionTask;

        private NotifyIcon _trayIcon;
        private ContextMenuStrip _trayMenu;

        // Menu Items
        private ToolStripMenuItem _statusMenuItem;
        private ToolStripMenuItem _portsHeaderMenuItem;
        private ToolStripMenuItem _refreshMenuItem;
        private ToolStripMenuItem _settingsMenuItem;
        private ToolStripMenuItem _runOnStartupMenuItem;
        private ToolStripMenuItem _aboutMenuItem;
        private ToolStripMenuItem _reportBugMenuItem;
        private ToolStripMenuItem _exitMenuItem;

        private const string StartupTaskName = "HWStatsStartup";

        public Form1()
        {
            InitializeComponent();
            _statsProvider = new StatsProvider(_hardwareMonitor);
        }

        #region Form Events and Setup
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Visible = false;
            ShowInTaskbar = false;
            InitializeTrayIcon();
            UsbDeviceNotifier.RegisterUsbDeviceNotification(this.Handle);

            // Start connection immediately on load
            _ = StartConnectionProcess();
        }

        private void InitializeTrayIcon()
        {
            _trayMenu = new ContextMenuStrip();

            _statusMenuItem = new ToolStripMenuItem("Status: Initializing...") { Enabled = false };
            _portsHeaderMenuItem = new ToolStripMenuItem("AVAILABLE PORTS:")
            {
                Enabled = false,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.DimGray
            };

            // Initialize Menu Items
            _refreshMenuItem = new ToolStripMenuItem("Refresh Ports", Resources.Refresh, OnRefreshPortsClick);
            _settingsMenuItem = new ToolStripMenuItem("Settings and Device Config", Resources.Settings, OnSettingsClick);
            _runOnStartupMenuItem = new ToolStripMenuItem("Run on Startup", null, OnRunOnStartupClick);
            _aboutMenuItem = new ToolStripMenuItem("About", Resources.info, (s, a) => new AboutBox1().ShowDialog());
            _reportBugMenuItem = new ToolStripMenuItem("Report bug / suggestions", Resources.Bug, OnReportBugClick);
            _exitMenuItem = new ToolStripMenuItem("Exit", Resources.Exit, (s, a) => Application.Exit());

            UpdateStartupTaskStatus();

            _trayMenu.Items.AddRange(new ToolStripItem[] {
                _statusMenuItem,
                new ToolStripSeparator(),
                _portsHeaderMenuItem
            });

            _trayIcon = new NotifyIcon
            {
                Icon = Resources.TrayIconRed,
                Text = "HWStats Monitor",
                Visible = true,
                ContextMenuStrip = _trayMenu
            };
            _trayIcon.MouseClick += OnTrayIconClick;
        }
        #endregion

        #region Core Connection and Data Loop
        private async System.Threading.Tasks.Task StartConnectionProcess(string manualPortName = null)
        {
            if (_connectionTask != null && !_connectionTask.IsCompleted)
            {
                _connectionCts?.Cancel();
                try { await _connectionTask; } catch (OperationCanceledException) { }
            }

            _deviceManager.DisconnectAll();
            _connectionCts = new CancellationTokenSource();
            var token = _connectionCts.Token;

            _connectionTask = System.Threading.Tasks.Task.Run(async () =>
            {
                bool connected = false;
                try
                {
                    token.ThrowIfCancellationRequested();

                    string portToTry = manualPortName ?? SettingsManager.CurrentSettings.LastUsedPort;
                    int baudRate = SettingsManager.CurrentSettings.BaudRate;
                    int refreshInterval = SettingsManager.CurrentSettings.RefreshInterval;
                    string customMsg = SettingsManager.CurrentSettings.CustomMessage;

                    if (baudRate <= 0) baudRate = 115200;
                    if (refreshInterval < 100) refreshInterval = 100;

                    if (string.IsNullOrEmpty(portToTry))
                    {
                        UpdateUI(AppStatus.Disconnected, "No port selected.");
                        return;
                    }

                    _deviceManager.RefreshDeviceList();

                    if (manualPortName != null)
                    {
                        UpdateUI(AppStatus.Searching, $"Connecting to {portToTry}...");
                        connected = _deviceManager.Connect(portToTry, baudRate);
                    }
                    else
                    {
                        const int maxRetries = 3;
                        const int retryDelayMs = 2000;
                        for (int i = 1; i <= maxRetries; i++)
                        {
                            token.ThrowIfCancellationRequested();
                            UpdateUI(AppStatus.Searching, $"Connecting to {portToTry} (Attempt {i}/{maxRetries})...");
                            if (_deviceManager.Connect(portToTry, baudRate)) { connected = true; break; }
                            if (i < maxRetries) await System.Threading.Tasks.Task.Delay(retryDelayMs, token);
                        }
                    }

                    token.ThrowIfCancellationRequested();

                    if (connected)
                    {
                        string connectedPortName = _deviceManager.GetActivePortNames();
                        UpdateUI(AppStatus.Connected, $"Connected to {connectedPortName}");

                        SettingsManager.CurrentSettings.LastUsedPort = connectedPortName;
                        SettingsManager.Save();

                        // --- THE LOOP ---
                        while (_deviceManager.IsConnected && !token.IsCancellationRequested)
                        {
                            // A. Start with Manual Mode
                            int finalMode = SettingsManager.CurrentSettings.DisplayMode;

                            // We need to fetch data first to populate IsGameRunning in StatsProvider
                            // But we need to pass finalMode to GetFormattedDataString. 
                            // Since mode depends on data, we do a "look-ahead" logic or update first.
                            // The cleanest way is to pass "0" first, check logic, then override if needed.

                            // To solve the "Chicken and Egg" problem, we will check conditions first.
                            // However, _statsProvider updates itself INSIDE GetFormattedDataString.
                            // So we call it once. If the mode needs to change, we call it again or 
                            // (better for performance) we trust the next cycle to catch up, 
                            // OR we separate the Update() logic. 

                            // For simplicity and efficiency: We calculate the mode based on *previous* frame's data 
                            // or we call update explicitly. Let's rely on the Update inside StatsProvider.
                            // We will assume "Normal" (or user set) mode initially.

                            string data = _statsProvider.GetFormattedDataString(finalMode);

                            // B. Auto-Trigger Logic (NEW: Exception List + (RTSS OR High GPU))
                            if (SettingsManager.CurrentSettings.AutoGameModeEnabled)
                            {
                                // 1. Check Exception List
                                string activeProcess = GameDetector.GetForegroundProcessName();
                                var exceptions = SettingsManager.CurrentSettings.ExceptionList.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                                bool isException = false;
                                foreach (var ex in exceptions)
                                {
                                    if (activeProcess.Contains(ex.Trim().ToLower()))
                                    {
                                        isException = true;
                                        break;
                                    }
                                }

                                if (!isException)
                                {
                                    // 2. Check Triggers: RTSS detected Game OR GPU Load > Threshold
                                    bool isRtssGame = _statsProvider.IsGameRunning;
                                    bool isHighGpu = _hardwareMonitor.GpuLoad >= SettingsManager.CurrentSettings.AutoGpuThreshold;

                                    if (isRtssGame || isHighGpu)
                                    {
                                        finalMode = 1; // FORCE GAME MODE

                                        // Re-generate string with correct mode '1' if we started with something else
                                        if (SettingsManager.CurrentSettings.DisplayMode != 1)
                                        {
                                            // Slight inefficiency here (double update) but ensures instant mode switching
                                            data = _statsProvider.GetFormattedDataString(finalMode);
                                        }
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(customMsg))
                            {
                                data += "#" + customMsg + "|";
                            }

                            _deviceManager.SendData(data);
                            await System.Threading.Tasks.Task.Delay(refreshInterval, token);
                        }
                    }
                    else
                    {
                        UpdateUI(AppStatus.Error, $"Failed to connect to {portToTry}.");
                    }
                }
                catch (OperationCanceledException) { Debug.WriteLine("Connection task cancelled."); }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error in connection process: {ex.Message}");
                    UpdateUI(AppStatus.Error, "An unexpected error occurred.");
                }
                finally
                {
                    if (!token.IsCancellationRequested)
                    {
                        _deviceManager.DisconnectAll();
                        UpdateUI(AppStatus.Disconnected, "Device disconnected.");
                    }
                }
            }, token);
        }
        #endregion

        #region UI Event Handlers
        private void OnSettingsClick(object sender, EventArgs e)
        {
            using (var settingsForm = new SettingsForm(_deviceManager))
            {
                if (settingsForm.ShowDialog() == DialogResult.OK)
                {
                    UpdateStartupTaskStatus();
                    _ = StartConnectionProcess();
                }
            }
        }

        private async void OnPortManualSelect(object sender, EventArgs e)
        {
            if (sender is ToolStripMenuItem item && item.Tag is string portName)
            {
                await StartConnectionProcess(portName);
            }
        }

        private void OnRefreshPortsClick(object sender, EventArgs e)
        {
            _deviceManager.RefreshDeviceList();
            PopulateComPortsMenu();
        }

        private void OnReportBugClick(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo("https://github.com/your-repo/issues") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Could not open browser. Error: {ex.Message}");
            }
        }

        private void OnTrayIconClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left || e.Button == MouseButtons.Right)
            {
                if (_connectionTask == null || _connectionTask.IsCompleted)
                {
                    _deviceManager.RefreshDeviceList();
                }
                PopulateComPortsMenu();
            }
            if (e.Button == MouseButtons.Left)
            {
                var method = typeof(NotifyIcon).GetMethod("ShowContextMenu", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                method?.Invoke(_trayIcon, null);
            }
        }

        private Action<AppStatus, string> _updateUiAction;
        private void UpdateUI(AppStatus status, string message = "")
        {
            if (InvokeRequired)
            {
                if (_updateUiAction == null) _updateUiAction = new Action<AppStatus, string>(UpdateUI);
                Invoke(_updateUiAction, status, message);
                return;
            }

            _statusMenuItem.Text = $"Status: {message}";
            switch (status)
            {
                case AppStatus.Disconnected:
                case AppStatus.Error:
                    _statusMenuItem.ForeColor = Color.OrangeRed;
                    _trayIcon.Icon = Resources.TrayIconRed;
                    break;
                case AppStatus.Searching:
                    _statusMenuItem.ForeColor = Color.Blue;
                    _trayIcon.Icon = Resources.TrayIcon1;
                    break;
                case AppStatus.Connected:
                    _statusMenuItem.ForeColor = Color.Green;
                    _trayIcon.Icon = Resources.TrayIconGreen;
                    break;
            }
            PopulateComPortsMenu();
        }

        private void PopulateComPortsMenu()
        {
            int headerIndex = _trayMenu.Items.IndexOf(_portsHeaderMenuItem);
            if (headerIndex == -1) return;

            while (_trayMenu.Items.Count > headerIndex + 1)
            {
                _trayMenu.Items.RemoveAt(headerIndex + 1);
            }

            var ports = _deviceManager.GetAvailablePorts();
            if (ports.Any())
            {
                foreach (var port in ports)
                {
                    var item = new ToolStripMenuItem($"{port.PortName}: {port.Description}", Resources.Serial, OnPortManualSelect)
                    {
                        Tag = port.PortName,
                        Checked = _deviceManager.IsPortConnected(port.PortName)
                    };
                    _trayMenu.Items.Add(item);
                }
            }
            else
            {
                _trayMenu.Items.Add(new ToolStripMenuItem("No COM ports found") { Enabled = false });
            }

            _trayMenu.Items.Add(new ToolStripSeparator());
            _trayMenu.Items.AddRange(new ToolStripItem[] {
                _refreshMenuItem,
                _runOnStartupMenuItem,
                _reportBugMenuItem,
                _aboutMenuItem,
                _settingsMenuItem,
                _exitMenuItem
            });
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == UsbDeviceNotifier.WmDevicechange)
            {
                if (!_deviceManager.IsConnected && (_connectionTask == null || _connectionTask.IsCompleted))
                {
                    _ = StartConnectionProcess();
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            _connectionCts?.Cancel();
            _connectionCts?.Dispose();
            _deviceManager.Dispose();
            _hardwareMonitor.Close();
            _trayIcon?.Dispose();
        }
        #endregion

        #region Startup Task Logic
        private void OnRunOnStartupClick(object sender, EventArgs e)
        {
            bool shouldBeEnabled = !_runOnStartupMenuItem.Checked;
            try
            {
                using (TaskService ts = new TaskService())
                {
                    if (shouldBeEnabled)
                    {
                        var td = ts.NewTask();
                        td.RegistrationInfo.Description = "Starts HWStats Monitor at logon.";
                        td.Principal.RunLevel = TaskRunLevel.Highest;
                        td.Triggers.Add(new LogonTrigger());
                        td.Actions.Add(new Microsoft.Win32.TaskScheduler.ExecAction(Application.ExecutablePath));
                        td.Settings.DisallowStartIfOnBatteries = false;
                        td.Settings.StopIfGoingOnBatteries = false;
                        ts.RootFolder.RegisterTaskDefinition(StartupTaskName, td);
                    }
                    else
                    {
                        if (ts.GetTask(StartupTaskName) != null)
                        {
                            ts.RootFolder.DeleteTask(StartupTaskName);
                        }
                    }
                    _runOnStartupMenuItem.Checked = shouldBeEnabled;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating startup task: {ex.Message}\nRun as Admin maybe?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateStartupTaskStatus()
        {
            try
            {
                using (TaskService ts = new TaskService())
                {
                    _runOnStartupMenuItem.Checked = (ts.GetTask(StartupTaskName) != null);
                }
            }
            catch
            {
                _runOnStartupMenuItem.Enabled = false;
            }
        }
        #endregion
    }
}