using IniParser;
using IniParser.Model;
using System.Diagnostics;
using System.IO;

namespace HWStats
{
    public class DeviceSettings
    {
        public string VendorID { get; set; } = "0000";
        public string ProductID { get; set; } = "0000";
        public string DeviceID { get; set; } = "0";
        public string LastUsedPort { get; set; } = string.Empty;
        public int BaudRate { get; set; } = 115200;
        public int RefreshInterval { get; set; } = 1000;
        public string CustomCpuName { get; set; } = "";
        public string CustomGpuName { get; set; } = "";
        public string CustomMessage { get; set; } = "";
        public int DisplayMode { get; set; } = 0; // 0=Normal, 1=Game, 2=Focus, 3=Nerd, 4=Gif
        public string City { get; set; } = "";
        public string Latitude { get; set; } = "";
        public string Longitude { get; set; } = "";
        public string WifiSSID { get; set; } = "";
        public string WifiPass { get; set; } = "";
        public string ApiKey { get; set; } = "";
        public string TimeOffset { get; set; } = "19800"; // Default IST
        public bool AutoGameModeEnabled { get; set; } = false;
        public int AutoGpuThreshold { get; set; } = 40; // Default 40%
        public string ExceptionList { get; set; } = "chrome,explorer,vlc"; // Default ignored apps
    }

    public static class SettingsManager
    {
        private const string ConfigFile = "Config.ini";
        private const string Section = "DeviceConfig";
        private const string VendorIdKey = "VendorID";
        private const string ProductIdKey = "ProductID";
        private const string DeviceIdKey = "DeviceID";
        private const string LastUsedPortKey = "LastUsedPort";
        private const string BaudRateKey = "BaudRate";
        private const string RefreshIntervalKey = "RefreshInterval";
        private const string CustomCpuKey = "CustomCpuName";
        private const string CustomGpuKey = "CustomGpuName";
        private const string CustomMessageKey = "CustomMessage";
        private const string DisplayModeKey = "DisplayMode";
        private const string CityKey = "City";
        private const string LatKey = "Latitude";
        private const string LonKey = "Longitude";
        private const string WifiSSIDKey = "WifiSSID";
        private const string WifiPassKey = "WifiPass";
        private const string ApiKeyKey = "ApiKey";
        private const string OffsetKey = "TimeOffset";
        private const string AutoGameKey = "AutoGameMode";
        private const string GpuThreshKey = "GpuThreshold";
        private const string ExceptionKey = "ExceptionList";

        private static readonly FileIniDataParser _parser = new FileIniDataParser();
        public static DeviceSettings CurrentSettings { get; private set; }

        static SettingsManager()
        {
            Load();
        }

        public static void Load()
        {
            if (!File.Exists(ConfigFile)) CreateDefaultIniFile();

            try
            {
                IniData data = _parser.ReadFile(ConfigFile);

                // FIXED: Syntax errors removed below
                CurrentSettings = new DeviceSettings
                {
                    VendorID = data[Section][VendorIdKey] ?? "0000",
                    ProductID = data[Section][ProductIdKey] ?? "0000",
                    DeviceID = data[Section][DeviceIdKey] ?? "0",
                    LastUsedPort = data[Section][LastUsedPortKey] ?? string.Empty,

                    // Fixed lines: Assigned directly to property
                    CustomCpuName = data[Section][CustomCpuKey] ?? "",
                    CustomGpuName = data[Section][CustomGpuKey] ?? "",

                    CustomMessage = data[Section][CustomMessageKey] ?? "",
                    City = data[Section][CityKey] ?? "",
                    Latitude = data[Section][LatKey] ?? "",
                    Longitude = data[Section][LonKey] ?? "",
                    WifiSSID = data[Section][WifiSSIDKey] ?? "",
                    WifiPass = data[Section][WifiPassKey] ?? "",
                    ApiKey = data[Section][ApiKeyKey] ?? "",
                    TimeOffset = data[Section][OffsetKey] ?? "19800"
                    
                };

                // Parse Integers safely
                if (int.TryParse(data[Section][BaudRateKey], out int baud)) CurrentSettings.BaudRate = baud;
                if (int.TryParse(data[Section][RefreshIntervalKey], out int interval)) CurrentSettings.RefreshInterval = interval;
                if (int.TryParse(data[Section][DisplayModeKey], out int mode)) CurrentSettings.DisplayMode = mode;
                bool.TryParse(data[Section][AutoGameKey], out bool auto);
                int.TryParse(data[Section][GpuThreshKey], out int thresh);

                CurrentSettings.AutoGameModeEnabled = auto;
                CurrentSettings.AutoGpuThreshold = (thresh > 0) ? thresh : 40;
                CurrentSettings.ExceptionList = data[Section][ExceptionKey] ?? "";
            }
            catch (System.Exception ex)
            {
                Debug.WriteLine($"Error loading INI: {ex.Message}");
                CurrentSettings = new DeviceSettings();
            }
        }

        public static void Save()
        {
            try
            {
                IniData data = new IniData();
                data[Section][VendorIdKey] = CurrentSettings.VendorID;
                data[Section][ProductIdKey] = CurrentSettings.ProductID;
                data[Section][DeviceIdKey] = CurrentSettings.DeviceID;
                data[Section][LastUsedPortKey] = CurrentSettings.LastUsedPort;
                data[Section][BaudRateKey] = CurrentSettings.BaudRate.ToString();
                data[Section][RefreshIntervalKey] = CurrentSettings.RefreshInterval.ToString();
                data[Section][CustomCpuKey] = CurrentSettings.CustomCpuName;
                data[Section][CustomGpuKey] = CurrentSettings.CustomGpuName;
                data[Section][CustomMessageKey] = CurrentSettings.CustomMessage;
                data[Section][DisplayModeKey] = CurrentSettings.DisplayMode.ToString();
                data[Section][CityKey] = CurrentSettings.City;
                data[Section][LatKey] = CurrentSettings.Latitude;
                data[Section][LonKey] = CurrentSettings.Longitude;
                data[Section][WifiSSIDKey] = CurrentSettings.WifiSSID;
                data[Section][WifiPassKey] = CurrentSettings.WifiPass;
                data[Section][ApiKeyKey] = CurrentSettings.ApiKey;
                data[Section][OffsetKey] = CurrentSettings.TimeOffset;
                data[Section][AutoGameKey] = CurrentSettings.AutoGameModeEnabled.ToString();
                data[Section][GpuThreshKey] = CurrentSettings.AutoGpuThreshold.ToString();
                data[Section][ExceptionKey] = CurrentSettings.ExceptionList;

                _parser.WriteFile(ConfigFile, data);
            }
            catch (System.Exception ex)
            {
                Debug.WriteLine($"Error saving INI: {ex.Message}");
            }
        }

        private static void CreateDefaultIniFile()
        {
            CurrentSettings = new DeviceSettings();
            Save();
        }
    }
}