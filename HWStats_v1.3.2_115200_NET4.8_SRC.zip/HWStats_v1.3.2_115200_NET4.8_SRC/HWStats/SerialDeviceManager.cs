using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Management;

public class PortInfo
{
    public string PortName { get; set; }
    public string Description { get; set; }
}

public class SerialDeviceManager : IDisposable
{
    private SerialPort _serialPort;
    public SerialPort SerialPort => _serialPort;
    private Dictionary<string, PortInfo> _availablePorts = new Dictionary<string, PortInfo>();

    public bool IsConnected => _serialPort != null && _serialPort.IsOpen;

    public SerialDeviceManager() => RefreshDeviceList();

    public void RefreshDeviceList()
    {
        _availablePorts.Clear();
        try
        {
            using (var searcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT Name, Description, PNPDeviceID FROM Win32_PnPEntity WHERE ClassGuid='{4d36e978-e325-11ce-bfc1-08002be10318}'"))
            {
                foreach (var device in searcher.Get())
                {
                    string name = device["Name"]?.ToString() ?? "";
                    int comIndex = name.IndexOf("(COM");
                    if (comIndex > -1)
                    {
                        string portName = name.Substring(comIndex + 1, name.LastIndexOf(")") - (comIndex + 1));
                        var portInfo = new PortInfo { PortName = portName, Description = device["Description"]?.ToString() ?? "N/A" };
                        if (!_availablePorts.ContainsKey(portName)) _availablePorts[portName] = portInfo;
                    }
                }
            }
        }
        catch (Exception ex) { Debug.WriteLine($"WMI Query Failed: {ex.Message}"); }
    }

    public List<PortInfo> GetAvailablePorts() => _availablePorts.Values.ToList();

    public bool Connect(string portName, int baudRate)
    {
        if (IsConnected && _serialPort.PortName == portName) return true;
        DisconnectAll(); // Ensure clean slate

        try
        {
            _serialPort = new SerialPort(portName, baudRate, Parity.None, 8, StopBits.One)
            {
                ReadTimeout = 500,
                WriteTimeout = 500,
                DtrEnable = true
            };
            _serialPort.Open();
            return _serialPort.IsOpen;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Connection Failed: {ex.Message}");
            _serialPort = null;
            return false;
        }
    }

    public void SendData(string data)
    {
        if (!IsConnected) return;
        try { _serialPort.WriteLine(data); }
        catch { DisconnectAll(); }
    }

    public bool IsPortConnected(string portName) => IsConnected && _serialPort.PortName == portName;

    public string GetActivePortNames() => IsConnected ? _serialPort.PortName : "None";

    public void DisconnectAll()
    {
        if (_serialPort != null)
        {
            if (_serialPort.IsOpen) try { _serialPort.Close(); } catch { }
            _serialPort.Dispose();
            _serialPort = null;
        }
    }

    public void Dispose() => DisconnectAll();
}