using LibreHardwareMonitor.Hardware;
using System.Collections.Generic;

public class StorageDevice
{
    public string Name { get; set; }
    public int Temperature { get; set; }
    public int UsedSpace { get; set; }
}

public class HardwareMonitor
{
    private readonly Computer _computer;
    public string CpuName { get; private set; }
    public string GpuName { get; private set; }
    public int CpuTemp { get; private set; }
    public int CpuLoad { get; private set; }
    public float CpuPower { get; private set; }
    public int CpuClock { get; private set; }
    public int GpuTemp { get; private set; }
    public int GpuLoad { get; private set; }
    public float GpuPower { get; private set; }
    public int GpuClock { get; private set; }
    public float RamUsed { get; private set; }
    public float RamAvailable { get; private set; }
    public int RamLoad { get; private set; }
    public List<StorageDevice> StorageDevices { get; private set; } = new List<StorageDevice>();
    public float DownloadSpeed { get; private set; }
    public float UploadSpeed { get; private set; }
    public float VrmTemp { get; private set; }
    public float CmosVoltage { get; private set; }
    public int CpuFanSpeed { get; private set; }
    public int CpuFanLoad { get; private set; }
    public int CpuPumpSpeed { get; private set; }
    public int GpuFanSpeed { get; private set; }
    public int GpuFanLoad { get; private set; }
    public int VirtualMemoryLoad { get; private set; }
    public float VirtualMemoryUsed { get; private set; }
    public float VirtualMemoryAvailable { get; private set; }
    public float VramTotal { get; private set; }
    public float VramUsed { get; private set; }
    public int VramLoad { get; private set; }

    public HardwareMonitor()
    {
        _computer = new Computer
        {
            IsCpuEnabled = true,
            IsGpuEnabled = true,
            IsMemoryEnabled = true,
            IsMotherboardEnabled = true,
            IsStorageEnabled = true,
            IsNetworkEnabled = true,
            IsControllerEnabled = true
        };
        _computer.Open();
    }

    public void Update()
    {
        StorageDevices.Clear();
        int maxCpuClock = 0;

        foreach (var hardware in _computer.Hardware)
        {
            hardware.Update();
            if (hardware.HardwareType == HardwareType.Cpu) CpuName = hardware.Name;
            if (hardware.HardwareType == HardwareType.GpuNvidia || hardware.HardwareType == HardwareType.GpuAmd) GpuName = hardware.Name;
            ProcessSensors(hardware, ref maxCpuClock);
            foreach (var sub in hardware.SubHardware) { sub.Update(); ProcessSensors(sub, ref maxCpuClock); }
        }
        if (maxCpuClock > 0) CpuClock = maxCpuClock;
    }

    private void ProcessSensors(IHardware hardware, ref int maxCpuClock)
    {
        if (hardware.HardwareType == HardwareType.Storage)
        {
            var drive = new StorageDevice { Name = hardware.Name };
            foreach (var sensor in hardware.Sensors)
            {
                if (!sensor.Value.HasValue) continue;
                if (sensor.SensorType == SensorType.Temperature) drive.Temperature = (int)sensor.Value.Value;
                if (sensor.SensorType == SensorType.Load && sensor.Name == "Used Space") drive.UsedSpace = (int)sensor.Value.Value;
            }
            StorageDevices.Add(drive);
        }

        foreach (var sensor in hardware.Sensors)
        {
            if (!sensor.Value.HasValue) continue;
            float val = sensor.Value.Value;

            if (hardware.HardwareType == HardwareType.Motherboard || hardware.HardwareType == HardwareType.SuperIO)
            {
                if (sensor.Name == "CPU Temperature" && sensor.SensorType == SensorType.Temperature) CpuTemp = (int)val;
                else if (sensor.Name == "VRM MOS" && sensor.SensorType == SensorType.Temperature) VrmTemp = val;
                else if (sensor.Name == "CMOS Battery" && sensor.SensorType == SensorType.Voltage) CmosVoltage = val;
                else if (sensor.Name == "CPU Fan" && sensor.SensorType == SensorType.Fan) CpuFanSpeed = (int)val;
                else if (sensor.Name == "CPU Fan" && sensor.SensorType == SensorType.Control) CpuFanLoad = (int)val;
                else if (sensor.Name == "Pump Fan" && sensor.SensorType == SensorType.Fan) CpuPumpSpeed = (int)val;
            }
            else if (hardware.HardwareType == HardwareType.Cpu)
            {
                if (sensor.Name == "CPU Package" && sensor.SensorType == SensorType.Temperature) CpuTemp = (int)val;
                else if (sensor.Name == "CPU Total" && sensor.SensorType == SensorType.Load) CpuLoad = (int)val;
                else if (sensor.Name == "CPU Package" && sensor.SensorType == SensorType.Power) CpuPower = (int)val;
                else if (sensor.Name.Contains("CPU Core") && sensor.SensorType == SensorType.Clock && val > maxCpuClock) maxCpuClock = (int)val;
            }
            else if (hardware.HardwareType == HardwareType.GpuNvidia || hardware.HardwareType == HardwareType.GpuAmd)
            {
                if (sensor.Name == "GPU Core" && sensor.SensorType == SensorType.Temperature) GpuTemp = (int)val;
                else if (sensor.Name == "GPU Core" && sensor.SensorType == SensorType.Load) GpuLoad = (int)val;
                else if (sensor.Name == "GPU Package" && sensor.SensorType == SensorType.Power) GpuPower = (int)val;
                else if (sensor.Name == "GPU Core" && sensor.SensorType == SensorType.Clock) GpuClock = (int)val;
                else if (sensor.Name.Contains("GPU Fan") && sensor.SensorType == SensorType.Fan && GpuFanSpeed == 0) GpuFanSpeed = (int)val;
                else if (sensor.Name.Contains("GPU Fan") && sensor.SensorType == SensorType.Control && GpuFanLoad == 0) GpuFanLoad = (int)val;
                else if (sensor.Name == "GPU Memory" && sensor.SensorType == SensorType.Load) VramLoad = (int)val;
                else if (sensor.Name == "GPU Memory Total") VramTotal = val / 1024;
                else if (sensor.Name == "D3D Dedicated Memory Used") VramUsed = val / 1024;
            }
            else if (hardware.HardwareType == HardwareType.Memory)
            {
                if (sensor.Name == "Memory" && sensor.SensorType == SensorType.Load) RamLoad = (int)val;
                else if (sensor.Name == "Memory Used") RamUsed = val;
                else if (sensor.Name == "Memory Available") RamAvailable = val;
                else if (sensor.Name == "Virtual Memory" && sensor.SensorType == SensorType.Load) VirtualMemoryLoad = (int)val;
                else if (sensor.Name == "Virtual Memory Used") VirtualMemoryUsed = val;
                else if (sensor.Name == "Virtual Memory Available") VirtualMemoryAvailable = val;
            }
            else if (hardware.HardwareType == HardwareType.Network && sensor.SensorType == SensorType.Throughput)
            {
                if (sensor.Name.Contains("Download")) DownloadSpeed = val * 8 / 1024 / 1024;
                else if (sensor.Name.Contains("Upload")) UploadSpeed = val * 8 / 1024 / 1024;
            }
        }
    }

    public void Close() => _computer.Close();
}