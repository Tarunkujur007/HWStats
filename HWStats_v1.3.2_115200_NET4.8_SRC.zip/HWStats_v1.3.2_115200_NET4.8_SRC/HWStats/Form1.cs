﻿using HWStats.Properties;
using Microsoft.Win32.TaskScheduler;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HWStats
{
    public partial class Form1 : Form
    {
        private enum AppStatus { Disconnected, Searching, Connected, Error }
        private volatile bool _isUploading = false;
        private readonly SerialDeviceManager _deviceManager = new SerialDeviceManager();
        private readonly HardwareMonitor _hardwareMonitor = new HardwareMonitor();
        private readonly StatsProvider _statsProvider;
        private CancellationTokenSource _connectionCts;
        private System.Threading.Tasks.Task _connectionTask;

        private NotifyIcon _trayIcon;
        private ContextMenuStrip _trayMenu;

        // Menu Items
        private ToolStripMenuItem _statusMenuItem;
        private ToolStripMenuItem _portsHeaderMenuItem;
        private ToolStripMenuItem _uploadMenuItem;
        private ToolStripMenuItem _deleteMenuItem;
        private ToolStripMenuItem _refreshMenuItem;
        private ToolStripMenuItem _settingsMenuItem;
        private ToolStripMenuItem _runOnStartupMenuItem;
        private ToolStripMenuItem _aboutMenuItem;
        private ToolStripMenuItem _reportBugMenuItem;
        private ToolStripMenuItem _exitMenuItem;

        private const string StartupTaskName = "HWStatsStartup";

        public Form1()
        {
            InitializeComponent();
            _statsProvider = new StatsProvider(_hardwareMonitor);
        }

        #region Form Events and Setup
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Visible = false;
            ShowInTaskbar = false;
            InitializeTrayIcon();
            UsbDeviceNotifier.RegisterUsbDeviceNotification(this.Handle);

            _ = StartConnectionProcess();
        }

        private void InitializeTrayIcon()
        {
            _trayMenu = new ContextMenuStrip();

            _statusMenuItem = new ToolStripMenuItem("Status: Initializing...") { Enabled = false };
            _portsHeaderMenuItem = new ToolStripMenuItem("AVAILABLE PORTS:")
            {
                Enabled = false,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.DimGray
            };

            // Define Items
            _uploadMenuItem = new ToolStripMenuItem("Upload Images (Multi-Select)", Resources.UploadImage, OnUploadImageClick);
            _deleteMenuItem = new ToolStripMenuItem("Delete All Images", Resources.Delete, OnDeleteImagesClick); 
            _refreshMenuItem = new ToolStripMenuItem("Refresh Ports", Resources.Refresh, OnRefreshPortsClick);
            _settingsMenuItem = new ToolStripMenuItem("Settings and Device Config", Resources.Settings, OnSettingsClick);
            _runOnStartupMenuItem = new ToolStripMenuItem("Run on Startup", null, OnRunOnStartupClick);
            _aboutMenuItem = new ToolStripMenuItem("About", Resources.info, (s, a) => new AboutBox1().ShowDialog());
            _reportBugMenuItem = new ToolStripMenuItem("Report bug / suggestions", Resources.Bug, OnReportBugClick);
            _exitMenuItem = new ToolStripMenuItem("Exit", Resources.Exit, (s, a) => Application.Exit());

            UpdateStartupTaskStatus();

            // Add Items to Menu
            _trayMenu.Items.AddRange(new ToolStripItem[] {
                _statusMenuItem,
                new ToolStripSeparator(),
                _portsHeaderMenuItem,
                new ToolStripSeparator(),
                _uploadMenuItem,
                _deleteMenuItem, 
                new ToolStripSeparator(),
                _refreshMenuItem,
                _runOnStartupMenuItem,
                _settingsMenuItem,
                _aboutMenuItem,
                _reportBugMenuItem,
                _exitMenuItem
            });

            _trayIcon = new NotifyIcon
            {
                Icon = Resources.TrayIconRed,
                Text = "HWStats Monitor",
                Visible = true,
                ContextMenuStrip = _trayMenu
            };
            _trayIcon.MouseClick += OnTrayIconClick;
        }
        #endregion

        #region Core Connection and Data Loop
        private async System.Threading.Tasks.Task StartConnectionProcess(string manualPortName = null)
        {
            if (_connectionTask != null && !_connectionTask.IsCompleted)
            {
                _connectionCts?.Cancel();
                try { await _connectionTask; } catch (OperationCanceledException) { }
            }

            _deviceManager.DisconnectAll();
            _connectionCts = new CancellationTokenSource();
            var token = _connectionCts.Token;

            _connectionTask = System.Threading.Tasks.Task.Run(async () =>
            {
                bool connected = false;
                try
                {
                    token.ThrowIfCancellationRequested();

                    string portToTry = manualPortName ?? SettingsManager.CurrentSettings.LastUsedPort;
                    int baudRate = SettingsManager.CurrentSettings.BaudRate;
                    int refreshInterval = SettingsManager.CurrentSettings.RefreshInterval;
                    string customMsg = SettingsManager.CurrentSettings.CustomMessage;

                    if (baudRate <= 0) baudRate = 115200;
                    if (refreshInterval < 100) refreshInterval = 100;

                    if (string.IsNullOrEmpty(portToTry))
                    {
                        UpdateUI(AppStatus.Disconnected, "No port selected.");
                        return;
                    }

                    _deviceManager.RefreshDeviceList();

                    if (manualPortName != null)
                    {
                        UpdateUI(AppStatus.Searching, $"Connecting to {portToTry}...");
                        connected = _deviceManager.Connect(portToTry, baudRate);
                    }
                    else
                    {
                        const int maxRetries = 3;
                        for (int i = 1; i <= maxRetries; i++)
                        {
                            token.ThrowIfCancellationRequested();
                            UpdateUI(AppStatus.Searching, $"Connecting to {portToTry} (Attempt {i}/{maxRetries})...");
                            if (_deviceManager.Connect(portToTry, baudRate)) { connected = true; break; }
                            if (i < maxRetries) await System.Threading.Tasks.Task.Delay(2000, token);
                        }
                    }

                    token.ThrowIfCancellationRequested();

                    if (connected)
                    {
                        string connectedPortName = _deviceManager.GetActivePortNames();
                        UpdateUI(AppStatus.Connected, $"Connected to {connectedPortName}");

                        SettingsManager.CurrentSettings.LastUsedPort = connectedPortName;
                        SettingsManager.Save();

                        // --- THE MAIN LOOP ---
                        while (_deviceManager.IsConnected && !token.IsCancellationRequested)
                        {
                            // 1. If Uploading or Deleting, Pause here automatically.
                            if (_isUploading)
                            {
                                await System.Threading.Tasks.Task.Delay(100, token);
                                continue;
                            }

                            // 2. Normal Data Logic
                            int finalMode = SettingsManager.CurrentSettings.DisplayMode;
                            string data = _statsProvider.GetFormattedDataString(finalMode);

                            // Auto-Trigger Game Mode Logic
                            if (SettingsManager.CurrentSettings.AutoGameModeEnabled)
                            {
                                string activeProcess = GameDetector.GetForegroundProcessName();
                                var exceptions = SettingsManager.CurrentSettings.ExceptionList.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                                bool isException = exceptions.Any(ex => activeProcess.Contains(ex.Trim().ToLower()));

                                if (!isException)
                                {
                                    bool isRtssGame = _statsProvider.IsGameRunning;
                                    bool isHighGpu = _hardwareMonitor.GpuLoad >= SettingsManager.CurrentSettings.AutoGpuThreshold;

                                    if (isRtssGame || isHighGpu)
                                    {
                                        finalMode = 1; // FORCE GAME MODE
                                        if (SettingsManager.CurrentSettings.DisplayMode != 1)
                                        {
                                            data = _statsProvider.GetFormattedDataString(finalMode);
                                        }
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(customMsg))
                            {
                                data += "#" + customMsg + "|";
                            }

                            _deviceManager.SendData(data);
                            await System.Threading.Tasks.Task.Delay(refreshInterval, token);
                        }
                    }
                    else
                    {
                        UpdateUI(AppStatus.Error, $"Failed to connect to {portToTry}.");
                    }
                }
                catch (OperationCanceledException) { Debug.WriteLine("Connection task cancelled."); }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error in connection process: {ex.Message}");
                    UpdateUI(AppStatus.Error, "An unexpected error occurred.");
                }
                finally
                {
                    if (!token.IsCancellationRequested)
                    {
                        _deviceManager.DisconnectAll();
                        UpdateUI(AppStatus.Disconnected, "Device disconnected.");
                    }
                }
            }, token);
        }
        #endregion

        #region Event Handlers

        // DELETE HANDLER 
        private async void OnDeleteImagesClick(object sender, EventArgs e)
        {
            if (!_deviceManager.IsConnected)
            {
                MessageBox.Show("Please connect to the ESP32 first!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete ALL images from the device?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _isUploading = true; // Pause data stream
                await System.Threading.Tasks.Task.Delay(250);

                try
                {
                    var port = _deviceManager.SerialPort;
                    if (port != null && port.IsOpen)
                    {
                        port.WriteLine("del:all"); // Send Delete Command
                        MessageBox.Show("Delete command sent. Device will restart.", "Sent", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to send delete command: {ex.Message}");
                }
                finally
                {
                    _isUploading = false; // Resume stream
                }
            }
        }


        private async void OnUploadImageClick(object sender, EventArgs e)
        {
            if (!_deviceManager.IsConnected)
            {
                MessageBox.Show("Please connect to the ESP32 first!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Multiselect = true;
                openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                openFileDialog.Title = "Select Image(s) for Display";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    _isUploading = true;
                    await System.Threading.Tasks.Task.Delay(100);

                    try
                    {
                        var port = _deviceManager.SerialPort;
                        if (port == null || !port.IsOpen) return;

                        
                        port.DiscardInBuffer();
                        port.DiscardOutBuffer();

                        port.ReadTimeout = 5000;

                        foreach (string filePath in openFileDialog.FileNames)
                        {
                            string fileName = Path.GetFileName(filePath);
                            byte[] fileBytes = File.ReadAllBytes(filePath);

                            
                            string header = $"`{fileName}:{fileBytes.Length}\n";
                            port.Write(header);

                            
                            string response = "";
                            try { response = port.ReadLine().Trim(); } catch { }

                            if (response == "READY")
                            {
                                int chunkSize = 1024;
                                int totalSent = 0;

                                
                                while (totalSent < fileBytes.Length)
                                {
                                    int len = Math.Min(chunkSize, fileBytes.Length - totalSent);
                                    port.Write(fileBytes, totalSent, len);
                                    totalSent += len;

                                    // Wait for 'NEXT' ack
                                    try
                                    {
                                        string ack = port.ReadLine().Trim();
                                        if (ack != "NEXT") throw new Exception($"Sync Error: Got '{ack}'");
                                    }
                                    catch (TimeoutException) { throw new Exception("Device write timeout."); }
                                }

                                try
                                {
                                    string final = port.ReadLine().Trim();
                                }
                                catch { }
                            }
                            else
                            {
                                MessageBox.Show($"Device did not accept upload.\nResponse: '{response}'", "Upload Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                        MessageBox.Show("All uploads processed!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Upload Failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        _isUploading = false;
                    }
                }
            }
        }

        private void OnSettingsClick(object sender, EventArgs e)
        {
            using (var settingsForm = new SettingsForm(_deviceManager))
            {
                if (settingsForm.ShowDialog() == DialogResult.OK)
                {
                    UpdateStartupTaskStatus();
                    _ = StartConnectionProcess();
                }
            }
        }

        private async void OnPortManualSelect(object sender, EventArgs e)
        {
            if (sender is ToolStripMenuItem item && item.Tag is string portName)
            {
                await StartConnectionProcess(portName);
            }
        }

        private void OnRefreshPortsClick(object sender, EventArgs e)
        {
            _deviceManager.RefreshDeviceList();
            PopulateComPortsMenu();
        }

        private void OnReportBugClick(object sender, EventArgs e)
        {
            try { Process.Start(new ProcessStartInfo("https://github.com/Tarunkujur007/HWStats/issues") { UseShellExecute = true }); }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void OnTrayIconClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left || e.Button == MouseButtons.Right)
            {
                if (_connectionTask == null || _connectionTask.IsCompleted)
                    _deviceManager.RefreshDeviceList();
                PopulateComPortsMenu();
            }
            if (e.Button == MouseButtons.Left)
            {
                var method = typeof(NotifyIcon).GetMethod("ShowContextMenu", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                method?.Invoke(_trayIcon, null);
            }
        }

        private Action<AppStatus, string> _updateUiAction;
        private void UpdateUI(AppStatus status, string message = "")
        {
            if (InvokeRequired)
            {
                if (_updateUiAction == null) _updateUiAction = new Action<AppStatus, string>(UpdateUI);
                Invoke(_updateUiAction, status, message);
                return;
            }

            _statusMenuItem.Text = $"Status: {message}";
            switch (status)
            {
                case AppStatus.Disconnected:
                case AppStatus.Error:
                    _statusMenuItem.ForeColor = Color.OrangeRed;
                    _trayIcon.Icon = Resources.TrayIconRed;
                    break;
                case AppStatus.Searching:
                    _statusMenuItem.ForeColor = Color.Blue;
                    _trayIcon.Icon = Resources.TrayIcon1;
                    break;
                case AppStatus.Connected:
                    _statusMenuItem.ForeColor = Color.Green;
                    _trayIcon.Icon = Resources.TrayIconGreen;
                    break;
            }
            PopulateComPortsMenu();
        }

        private void PopulateComPortsMenu()
        {
            int headerIndex = _trayMenu.Items.IndexOf(_portsHeaderMenuItem);
            if (headerIndex == -1) return;

            while (_trayMenu.Items.Count > headerIndex + 1)
            {
                // Stop removing when we hit the separator (Protects Upload/Delete options)
                if (_trayMenu.Items[headerIndex + 1] is ToolStripSeparator)
                    break;
                _trayMenu.Items.RemoveAt(headerIndex + 1);
            }

            var ports = _deviceManager.GetAvailablePorts();
            if (ports.Any())
            {
                int insertIndex = headerIndex + 1;
                foreach (var port in ports)
                {
                    var item = new ToolStripMenuItem($"{port.PortName}: {port.Description}", Resources.Serial, OnPortManualSelect)
                    {
                        Tag = port.PortName,
                        Checked = _deviceManager.IsPortConnected(port.PortName)
                    };
                    _trayMenu.Items.Insert(insertIndex++, item);
                }
            }
            else
            {
                _trayMenu.Items.Insert(headerIndex + 1, new ToolStripMenuItem("No COM ports found") { Enabled = false });
            }
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == UsbDeviceNotifier.WmDevicechange)
            {
                if (!_deviceManager.IsConnected && (_connectionTask == null || _connectionTask.IsCompleted))
                {
                    _ = StartConnectionProcess();
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            _connectionCts?.Cancel();
            _connectionCts?.Dispose();
            _deviceManager.Dispose();
            _hardwareMonitor.Close();
            _trayIcon?.Dispose();
        }
        #endregion

        #region Startup Task Logic
        private void OnRunOnStartupClick(object sender, EventArgs e)
        {
            bool shouldBeEnabled = !_runOnStartupMenuItem.Checked;
            try
            {
                using (TaskService ts = new TaskService())
                {
                    if (shouldBeEnabled)
                    {
                        var td = ts.NewTask();
                        td.RegistrationInfo.Description = "Starts HWStats Monitor at logon.";
                        td.Principal.RunLevel = TaskRunLevel.Highest;
                        td.Triggers.Add(new LogonTrigger());
                        td.Actions.Add(new Microsoft.Win32.TaskScheduler.ExecAction(Application.ExecutablePath));
                        td.Settings.DisallowStartIfOnBatteries = false;
                        td.Settings.StopIfGoingOnBatteries = false;
                        ts.RootFolder.RegisterTaskDefinition(StartupTaskName, td);
                    }
                    else
                    {
                        if (ts.GetTask(StartupTaskName) != null) ts.RootFolder.DeleteTask(StartupTaskName);
                    }
                    _runOnStartupMenuItem.Checked = shouldBeEnabled;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating startup task: {ex.Message}\nRun as Admin maybe?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateStartupTaskStatus()
        {
            try
            {
                using (TaskService ts = new TaskService())
                {
                    _runOnStartupMenuItem.Checked = (ts.GetTask(StartupTaskName) != null);
                }
            }
            catch { _runOnStartupMenuItem.Enabled = false; }
        }
        #endregion
    }
}