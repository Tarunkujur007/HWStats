using System;
using System.Drawing;
using System.Windows.Forms;

namespace HWStats
{
    public partial class SettingsForm : Form
    {
        private readonly SerialDeviceManager _deviceManager;
        private ComboBox cboBaudRate;
        private NumericUpDown numRefreshInterval;
        private TextBox txtCustomMessage, txtCustomCpu, txtCustomGpu, txtExceptions;
        private TextBox txtCity, txtLat, txtLon, txtSSID, txtPass, txtAPI, txtOffset;
        private CheckBox chkAutoGame, chk12Hour;
        private NumericUpDown numGpuThreshold;
        private RadioButton rbNormal, rbGaming, rbFocus, rbNerd, rbGif;
        private Button btnSave, btnCancel;

        public SettingsForm(SerialDeviceManager deviceManager)
        {
            _deviceManager = deviceManager;
            InitializeComponentCustom();
            LoadCurrentSettings();
        }

        private void LoadCurrentSettings()
        {
            cboBaudRate.SelectedItem = SettingsManager.CurrentSettings.BaudRate.ToString();
            if (cboBaudRate.SelectedIndex == -1) cboBaudRate.Text = "115200";

            numRefreshInterval.Value = Math.Max(100, SettingsManager.CurrentSettings.RefreshInterval);
            txtCustomMessage.Text = SettingsManager.CurrentSettings.CustomMessage;
            txtCustomCpu.Text = SettingsManager.CurrentSettings.CustomCpuName;
            txtCustomGpu.Text = SettingsManager.CurrentSettings.CustomGpuName;
            chkAutoGame.Checked = SettingsManager.CurrentSettings.AutoGameModeEnabled;
            numGpuThreshold.Value = SettingsManager.CurrentSettings.AutoGpuThreshold;
            txtExceptions.Text = SettingsManager.CurrentSettings.ExceptionList;

            switch (SettingsManager.CurrentSettings.DisplayMode)
            {
                case 1: rbGaming.Checked = true; break;
                case 2: rbFocus.Checked = true; break;
                case 3: rbNerd.Checked = true; break;
                case 4: rbGif.Checked = true; break;
                default: rbNormal.Checked = true; break;
            }

            txtCity.Text = SettingsManager.CurrentSettings.City;
            txtLat.Text = SettingsManager.CurrentSettings.Latitude;
            txtLon.Text = SettingsManager.CurrentSettings.Longitude;
            txtSSID.Text = SettingsManager.CurrentSettings.WifiSSID;
            txtPass.Text = SettingsManager.CurrentSettings.WifiPass;
            txtAPI.Text = SettingsManager.CurrentSettings.ApiKey;
            txtOffset.Text = SettingsManager.CurrentSettings.TimeOffset;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (int.TryParse(cboBaudRate.Text, out int baud)) SettingsManager.CurrentSettings.BaudRate = baud;
            SettingsManager.CurrentSettings.RefreshInterval = (int)numRefreshInterval.Value;
            SettingsManager.CurrentSettings.CustomMessage = txtCustomMessage.Text;
            SettingsManager.CurrentSettings.CustomCpuName = txtCustomCpu.Text;
            SettingsManager.CurrentSettings.CustomGpuName = txtCustomGpu.Text;
            SettingsManager.CurrentSettings.AutoGameModeEnabled = chkAutoGame.Checked;
            SettingsManager.CurrentSettings.AutoGpuThreshold = (int)numGpuThreshold.Value;
            SettingsManager.CurrentSettings.ExceptionList = txtExceptions.Text.ToLower();

            int mode = 0;
            if (rbGaming.Checked) mode = 1;
            else if (rbFocus.Checked) mode = 2;
            else if (rbNerd.Checked) mode = 3;
            else if (rbGif.Checked) mode = 4;
            SettingsManager.CurrentSettings.DisplayMode = mode;

            SettingsManager.CurrentSettings.City = txtCity.Text;
            SettingsManager.CurrentSettings.Latitude = txtLat.Text;
            SettingsManager.CurrentSettings.Longitude = txtLon.Text;
            SettingsManager.CurrentSettings.WifiSSID = txtSSID.Text;
            SettingsManager.CurrentSettings.WifiPass = txtPass.Text;
            SettingsManager.CurrentSettings.ApiKey = txtAPI.Text;
            SettingsManager.CurrentSettings.TimeOffset = txtOffset.Text;

            SettingsManager.Save();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnFlashConfig_Click(object sender, EventArgs e)
        {
            if (_deviceManager == null || !_deviceManager.IsConnected)
            {
                MessageBox.Show("Device not connected!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string is12h = chk12Hour.Checked ? "1" : "0";
            string configData = $"*{txtOffset.Text};{txtCity.Text};{txtLat.Text};{txtLon.Text};{txtSSID.Text};{txtPass.Text};{txtAPI.Text};{is12h}";
            try
            {
                _deviceManager.SendData(configData);
                MessageBox.Show("Configuration Sent!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show($"Failed: {ex.Message}"); }
        }

        private void btnAutoOffset_Click(object sender, EventArgs e)
        {
            txtOffset.Text = ((long)TimeZoneInfo.Local.GetUtcOffset(DateTime.Now).TotalSeconds).ToString();
        }

        private void InitializeComponentCustom()
        {
            this.Size = new Size(500, 850);
            this.Text = "Settings & Device Config";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.AutoScroll = true;

            int x = 20, y = 20;

            this.Controls.Add(new Label { Text = "Baud Rate:", Location = new Point(x, y), AutoSize = true });
            cboBaudRate = new ComboBox { Location = new Point(x + 100, y - 3), Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
            cboBaudRate.Items.AddRange(new object[] { "9600", "19200", "38400", "57600", "115200", "230400", "460800", "921600" });
            this.Controls.Add(cboBaudRate);

            y += 35;
            this.Controls.Add(new Label { Text = "Refresh (ms):", Location = new Point(x, y), AutoSize = true });
            numRefreshInterval = new NumericUpDown { Location = new Point(x + 100, y - 3), Width = 120, Minimum = 100, Maximum = 60000 };
            this.Controls.Add(numRefreshInterval);

            y += 35;
            this.Controls.Add(new Label { Text = "Custom Text:", Location = new Point(x, y), AutoSize = true });
            txtCustomMessage = new TextBox { Location = new Point(x + 100, y - 3), Width = 200 };
            this.Controls.Add(txtCustomMessage);

            y += 45;
            GroupBox grpNames = new GroupBox { Text = "Custom Hardware Names", Location = new Point(x, y), Size = new Size(440, 90) };
            grpNames.Controls.Add(new Label { Text = "CPU Name:", Location = new Point(15, 25), AutoSize = true });
            txtCustomCpu = new TextBox { Location = new Point(90, 22), Width = 300 };
            grpNames.Controls.Add(txtCustomCpu);
            grpNames.Controls.Add(new Label { Text = "GPU Name:", Location = new Point(15, 55), AutoSize = true });
            txtCustomGpu = new TextBox { Location = new Point(90, 52), Width = 300 };
            grpNames.Controls.Add(txtCustomGpu);
            this.Controls.Add(grpNames);

            y += 100;
            GroupBox grpAuto = new GroupBox { Text = "Auto-Trigger Game Mode", Location = new Point(x, y), Size = new Size(440, 100) };
            chkAutoGame = new CheckBox { Text = "Enable Auto-Switching", Location = new Point(15, 20), AutoSize = true };
            grpAuto.Controls.Add(chkAutoGame);
            grpAuto.Controls.Add(new Label { Text = "Trigger if GPU >", Location = new Point(200, 22), AutoSize = true });
            numGpuThreshold = new NumericUpDown { Location = new Point(290, 20), Width = 50, Minimum = 1, Maximum = 99 };
            grpAuto.Controls.Add(numGpuThreshold);
            grpAuto.Controls.Add(new Label { Text = "%", Location = new Point(345, 22), AutoSize = true });
            grpAuto.Controls.Add(new Label { Text = "Exceptions (.exe file):", Location = new Point(15, 60), AutoSize = true });
            txtExceptions = new TextBox { Location = new Point(120, 58), Width = 300 };
            grpAuto.Controls.Add(txtExceptions);
            grpAuto.Controls.Add(new Label { Text = "(e.g., chrome, vlc, code)", Location = new Point(110, 80), ForeColor = Color.Gray, Font = new Font(this.Font.FontFamily, 7) });
            this.Controls.Add(grpAuto);

            y += 110;
            GroupBox grpMode = new GroupBox { Text = "Manual Display Mode", Location = new Point(x, y), Size = new Size(440, 60) };
            rbNormal = new RadioButton { Text = "Normal", Location = new Point(10, 20), AutoSize = true };
            rbGaming = new RadioButton { Text = "Gaming", Location = new Point(80, 20), AutoSize = true };
            rbFocus = new RadioButton { Text = "Focus", Location = new Point(160, 20), AutoSize = true };
            rbNerd = new RadioButton { Text = "Nerd", Location = new Point(230, 20), AutoSize = true };
            rbGif = new RadioButton { Text = "GIF", Location = new Point(290, 20), AutoSize = true };
            grpMode.Controls.AddRange(new Control[] { rbNormal, rbGaming, rbFocus, rbNerd, rbGif });
            this.Controls.Add(grpMode);

            y += 70;
            GroupBox grpConfig = new GroupBox { Text = "Device Offline Config (Weather/Clock)", Location = new Point(x, y), Size = new Size(440, 280) };
            int gx = 15, gy = 25;
            grpConfig.Controls.Add(new Label { Text = "City:", Location = new Point(gx, gy), AutoSize = true });
            txtCity = new TextBox { Location = new Point(gx + 60, gy - 3), Width = 120 };
            grpConfig.Controls.Add(txtCity);
            grpConfig.Controls.Add(new Label { Text = "TZ Offset:", Location = new Point(gx + 200, gy), AutoSize = true });
            txtOffset = new TextBox { Location = new Point(gx + 270, gy - 3), Width = 80 };
            grpConfig.Controls.Add(txtOffset);
            Button btnAutoTz = new Button { Text = "Auto", Location = new Point(gx + 360, gy - 5), Width = 50, Height = 23 };
            btnAutoTz.Click += btnAutoOffset_Click;
            grpConfig.Controls.Add(btnAutoTz);

            gy += 35;
            grpConfig.Controls.Add(new Label { Text = "Lat:", Location = new Point(gx, gy), AutoSize = true });
            txtLat = new TextBox { Location = new Point(gx + 60, gy - 3), Width = 120 };
            grpConfig.Controls.Add(txtLat);
            grpConfig.Controls.Add(new Label { Text = "Lon:", Location = new Point(gx + 200, gy), AutoSize = true });
            txtLon = new TextBox { Location = new Point(gx + 270, gy - 3), Width = 120 };
            grpConfig.Controls.Add(txtLon);

            gy += 35;
            grpConfig.Controls.Add(new Label { Text = "WiFi SSID:", Location = new Point(gx, gy), AutoSize = true });
            txtSSID = new TextBox { Location = new Point(gx + 80, gy - 3), Width = 300 };
            grpConfig.Controls.Add(txtSSID);

            gy += 35;
            grpConfig.Controls.Add(new Label { Text = "WiFi Pass:", Location = new Point(gx, gy), AutoSize = true });
            txtPass = new TextBox { Location = new Point(gx + 80, gy - 3), Width = 300, PasswordChar = '*' };
            grpConfig.Controls.Add(txtPass);

            gy += 35;
            grpConfig.Controls.Add(new Label { Text = "API Key:", Location = new Point(gx, gy), AutoSize = true });
            txtAPI = new TextBox { Location = new Point(gx + 80, gy - 3), Width = 300, PasswordChar = '*' };
            grpConfig.Controls.Add(txtAPI);

            gy += 35;
            chk12Hour = new CheckBox { Text = "Use 12-Hour Format (AM/PM)", Location = new Point(gx + 80, gy), AutoSize = true };
            grpConfig.Controls.Add(chk12Hour);

            gy += 35;
            Button btnFlash = new Button { Text = "Flash Settings to ESP32", Location = new Point(gx + 80, gy), Width = 300, BackColor = Color.LightBlue, Height = 30 };
            btnFlash.Click += btnFlashConfig_Click;
            grpConfig.Controls.Add(btnFlash);
            this.Controls.Add(grpConfig);

            y += 300;
            btnSave = new Button { Text = "Save Settings", Location = new Point(240, y), Width = 100, Height = 30, DialogResult = DialogResult.OK };
            btnSave.Click += btnSave_Click;
            btnCancel = new Button { Text = "Cancel", Location = new Point(360, y), Width = 100, Height = 30, DialogResult = DialogResult.Cancel };
            btnCancel.Click += (s, ev) => this.Close();
            this.Controls.Add(btnSave);
            this.Controls.Add(btnCancel);
            this.ClientSize = new Size(480, y + 50);
        }
    }
}