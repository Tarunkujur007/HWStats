using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

public static class GameDetector
{
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    public static string GetForegroundProcessName()
    {
        try
        {
            IntPtr hWnd = GetForegroundWindow();
            if (hWnd == IntPtr.Zero) return "";
            GetWindowThreadProcessId(hWnd, out uint procId);
            using (Process proc = Process.GetProcessById((int)procId))
            {
                return proc.ProcessName.ToLower();
            }
        }
        catch { return ""; }
    }

    public static string GetGameNameFromPid(int pid)
    {
        try
        {
            using (Process p = Process.GetProcessById(pid))
            {
                string title = p.MainWindowTitle;
                if (string.IsNullOrWhiteSpace(title)) title = p.ProcessName;
                return CleanGameName(title);
            }
        }
        catch { return ""; }
    }

    private static string CleanGameName(string input)
    {
        if (string.IsNullOrEmpty(input)) return "";
        string cleaned = input;
        cleaned = Regex.Replace(cleaned, @"[���]", "");
        cleaned = Regex.Replace(cleaned, @"\s*\(.*?\)", "");
        cleaned = Regex.Replace(cleaned, @"\s*\[.*?\]", "");
        cleaned = Regex.Replace(cleaned, @"\s+(v\d+|build|version).*$", "", RegexOptions.IgnoreCase);
        cleaned = Regex.Replace(cleaned, @"\s{2,}", " ");
        return cleaned.Trim();
    }
}