using System;
using System.Reflection;
using System.Windows.Forms;

namespace HWStats
{
    partial class AboutBox1 : Form
    {
        public AboutBox1()
        {
            InitializeComponent();
            var asm = Assembly.GetExecutingAssembly();

            this.Text = "About HWStats";
            this.labelProductName.Text = "HWStats Monitor";
            this.labelVersion.Text = $"Version {asm.GetName().Version}";
            this.labelCopyright.Text = "Copyright � 2026";
            this.labelCompanyName.Text = "Hardware Stats Inc.";

            this.textBoxDescription.Text =
                "HWStats is a lightweight, system tray utility that reads your PC's vital hardware statistics and transmits them over a serial connection.\r\n\r\n" +
                "Features:\r\n" +
                "� Real-time monitoring of CPU, GPU, RAM.\r\n" +
                "� FPS via RTSS.\r\n" +
                "� Powered by: LibreHardwareMonitor, RTSSSharedMemoryNET, NAudio and TaskScheduler.";
        }

        private void okButton_Click(object sender, EventArgs e) => this.Close();
    }
}