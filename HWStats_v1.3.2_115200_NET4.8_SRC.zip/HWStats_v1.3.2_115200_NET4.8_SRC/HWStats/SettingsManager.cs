using IniParser;
using IniParser.Model;
using System.Diagnostics;
using System.IO;

namespace HWStats
{
    public class DeviceSettings
    {
        public string LastUsedPort { get; set; } = string.Empty;
        public int BaudRate { get; set; } = 115200;
        public int RefreshInterval { get; set; } = 1000;
        public string CustomCpuName { get; set; } = "";
        public string CustomGpuName { get; set; } = "";
        public string CustomMessage { get; set; } = "";
        public int DisplayMode { get; set; } = 0;
        public string City { get; set; } = "";
        public string Latitude { get; set; } = "";
        public string Longitude { get; set; } = "";
        public string WifiSSID { get; set; } = "";
        public string WifiPass { get; set; } = "";
        public string ApiKey { get; set; } = "";
        public string TimeOffset { get; set; } = "19800"; // Default IST
        public bool AutoGameModeEnabled { get; set; } = false;
        public int AutoGpuThreshold { get; set; } = 40;
        public string ExceptionList { get; set; } = "chrome,explorer,vlc";
    }

    public static class SettingsManager
    {
        private const string ConfigFile = "Config.ini";
        private const string Section = "DeviceConfig";
        private static readonly FileIniDataParser _parser = new FileIniDataParser();
        public static DeviceSettings CurrentSettings { get; private set; }

        static SettingsManager() => Load();

        public static void Load()
        {
            if (!File.Exists(ConfigFile)) { CurrentSettings = new DeviceSettings(); Save(); return; }
            try
            {
                IniData data = _parser.ReadFile(ConfigFile);
                CurrentSettings = new DeviceSettings
                {
                    LastUsedPort = data[Section]["LastUsedPort"] ?? string.Empty,
                    BaudRate = int.TryParse(data[Section]["BaudRate"], out int b) ? b : 115200,
                    RefreshInterval = int.TryParse(data[Section]["RefreshInterval"], out int r) ? r : 1000,
                    CustomCpuName = data[Section]["CustomCpuName"] ?? "",
                    CustomGpuName = data[Section]["CustomGpuName"] ?? "",
                    CustomMessage = data[Section]["CustomMessage"] ?? "",
                    DisplayMode = int.TryParse(data[Section]["DisplayMode"], out int m) ? m : 0,
                    City = data[Section]["City"] ?? "",
                    Latitude = data[Section]["Latitude"] ?? "",
                    Longitude = data[Section]["Longitude"] ?? "",
                    WifiSSID = data[Section]["WifiSSID"] ?? "",
                    WifiPass = data[Section]["WifiPass"] ?? "",
                    ApiKey = data[Section]["ApiKey"] ?? "",
                    TimeOffset = data[Section]["TimeOffset"] ?? "19800",
                    AutoGameModeEnabled = bool.TryParse(data[Section]["AutoGameMode"], out bool a) && a,
                    AutoGpuThreshold = int.TryParse(data[Section]["GpuThreshold"], out int t) ? t : 40,
                    ExceptionList = data[Section]["ExceptionList"] ?? "chrome,explorer,vlc"
                };
            }
            catch { CurrentSettings = new DeviceSettings(); }
        }

        public static void Save()
        {
            try
            {
                IniData data = new IniData();
                data[Section]["LastUsedPort"] = CurrentSettings.LastUsedPort;
                data[Section]["BaudRate"] = CurrentSettings.BaudRate.ToString();
                data[Section]["RefreshInterval"] = CurrentSettings.RefreshInterval.ToString();
                data[Section]["CustomCpuName"] = CurrentSettings.CustomCpuName;
                data[Section]["CustomGpuName"] = CurrentSettings.CustomGpuName;
                data[Section]["CustomMessage"] = CurrentSettings.CustomMessage;
                data[Section]["DisplayMode"] = CurrentSettings.DisplayMode.ToString();
                data[Section]["City"] = CurrentSettings.City;
                data[Section]["Latitude"] = CurrentSettings.Latitude;
                data[Section]["Longitude"] = CurrentSettings.Longitude;
                data[Section]["WifiSSID"] = CurrentSettings.WifiSSID;
                data[Section]["WifiPass"] = CurrentSettings.WifiPass;
                data[Section]["ApiKey"] = CurrentSettings.ApiKey;
                data[Section]["TimeOffset"] = CurrentSettings.TimeOffset;
                data[Section]["AutoGameMode"] = CurrentSettings.AutoGameModeEnabled.ToString();
                data[Section]["GpuThreshold"] = CurrentSettings.AutoGpuThreshold.ToString();
                data[Section]["ExceptionList"] = CurrentSettings.ExceptionList;
                _parser.WriteFile(ConfigFile, data);
            }
            catch (System.Exception ex) { Debug.WriteLine($"Error saving INI: {ex.Message}"); }
        }
    }
}