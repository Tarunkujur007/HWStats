using IniParser;
using IniParser.Model;
using System.Diagnostics;
using System.IO;

namespace HWStats
{
    public class DeviceSettings
    {
        public string VendorID { get; set; } = "0000";
        public string ProductID { get; set; } = "0000";
        public string DeviceID { get; set; } = "0";
        public string LastUsedPort { get; set; } = string.Empty;
        public int BaudRate { get; set; } = 115200;
        public int RefreshInterval { get; set; } = 1000;
        public string CustomMessage { get; set; } = "";
    }

    public static class SettingsManager
    {
        private const string ConfigFile = "Config.ini";
        private const string Section = "DeviceConfig";

        // Key Names
        private const string VendorIdKey = "VendorID";
        private const string ProductIdKey = "ProductID";
        private const string DeviceIdKey = "DeviceID";
        private const string LastUsedPortKey = "LastUsedPort";
        private const string BaudRateKey = "BaudRate";
        private const string RefreshIntervalKey = "RefreshInterval";
        private const string CustomMessageKey = "CustomMessage";

        private static readonly FileIniDataParser _parser = new FileIniDataParser();
        public static DeviceSettings CurrentSettings { get; private set; }

        static SettingsManager()
        {
            Load();
        }

        public static void Load()
        {
            if (!File.Exists(ConfigFile)) CreateDefaultIniFile();

            try
            {
                IniData data = _parser.ReadFile(ConfigFile);
                CurrentSettings = new DeviceSettings
                {
                    VendorID = data[Section][VendorIdKey] ?? "0000",
                    ProductID = data[Section][ProductIdKey] ?? "0000",
                    DeviceID = data[Section][DeviceIdKey] ?? "0",
                    LastUsedPort = data[Section][LastUsedPortKey] ?? string.Empty,
                    CustomMessage = data[Section][CustomMessageKey] ?? ""
                };

                // Parse Integers safely
                if (int.TryParse(data[Section][BaudRateKey], out int baud))
                    CurrentSettings.BaudRate = baud;

                if (int.TryParse(data[Section][RefreshIntervalKey], out int interval))
                    CurrentSettings.RefreshInterval = interval;
            }
            catch (System.Exception ex)
            {
                Debug.WriteLine($"Error loading INI: {ex.Message}");
                CurrentSettings = new DeviceSettings();
            }
        }

        public static void Save()
        {
            try
            {
                IniData data = new IniData();
                data[Section][VendorIdKey] = CurrentSettings.VendorID;
                data[Section][ProductIdKey] = CurrentSettings.ProductID;
                data[Section][DeviceIdKey] = CurrentSettings.DeviceID;
                data[Section][LastUsedPortKey] = CurrentSettings.LastUsedPort;

                // Save New Settings
                data[Section][BaudRateKey] = CurrentSettings.BaudRate.ToString();
                data[Section][RefreshIntervalKey] = CurrentSettings.RefreshInterval.ToString();
                data[Section][CustomMessageKey] = CurrentSettings.CustomMessage;

                _parser.WriteFile(ConfigFile, data);
            }
            catch (System.Exception ex)
            {
                Debug.WriteLine($"Error saving INI: {ex.Message}");
            }
        }

        private static void CreateDefaultIniFile()
        {
            CurrentSettings = new DeviceSettings();
            Save();
        }
    }
}