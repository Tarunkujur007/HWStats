using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Management; 

public class PortInfo
{
    public string PortName { get; set; }
    public string Description { get; set; }
    public string PnpDeviceId { get; set; } // This ID is unique even for identical devices
}

public class SerialDeviceManager : IDisposable
{
    //Handles multiple simultaneous connections using a Dictionary 
    private readonly Dictionary<string, SerialPort> _activePorts = new Dictionary<string, SerialPort>();

    //Stores available ports by unique ID to prevent losing duplicates
    private Dictionary<string, PortInfo> _availablePorts = new Dictionary<string, PortInfo>();


    //True if at least one serial port is currently connected and open.
    public bool IsConnected => _activePorts.Any(p => p.Value.IsOpen);

    public SerialDeviceManager()
    {
        RefreshDeviceList();
    }

    // Scans the system using WMI to find all available COM ports with detailed descriptions.
    // This now correctly handles multiple identical devices.
    public void RefreshDeviceList()
    {
        _availablePorts = new Dictionary<string, PortInfo>();
        string query = "SELECT Name, Description, PNPDeviceID FROM Win32_PnPEntity WHERE ClassGuid='{4d36e978-e325-11ce-bfc1-08002be10318}'";

        try
        {
            using (var searcher = new ManagementObjectSearcher("root\\CIMV2", query))
            {
                foreach (var device in searcher.Get())
                {
                    string name = device["Name"]?.ToString() ?? "";
                    string pnpId = device["PNPDeviceID"]?.ToString() ?? "";
                    int comIndex = name.IndexOf("(COM");

                    if (comIndex > -1 && !string.IsNullOrEmpty(pnpId))
                    {
                        string portName = name.Substring(comIndex + 1, name.LastIndexOf(")") - (comIndex + 1));
                        var portInfo = new PortInfo
                        {
                            PortName = portName,
                            Description = device["Description"]?.ToString() ?? "N/A",
                            PnpDeviceId = pnpId
                        };

                        // Use the unique PnpDeviceId as the key to prevent overwrites from identical hardware
                        if (!_availablePorts.ContainsKey(pnpId))
                        {
                            _availablePorts.Add(pnpId, portInfo);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"WMI Query Failed during device refresh: {ex.Message}");
            _availablePorts.Clear();
        }
    }

    // Returns a list of all detected serial port devices.
    public List<PortInfo> GetAvailablePorts() => _availablePorts.Values.ToList();


    // Connects to a specific port by name, or auto-detects based on hardware IDs.
    public bool Connect(string portName, int baudRate, string vidPid = null, string deviceId = null)
    {
        PortInfo deviceToConnect = null;

        if (!string.IsNullOrEmpty(portName))
        {
            deviceToConnect = _availablePorts.Values.FirstOrDefault(d => d.PortName.Equals(portName, StringComparison.OrdinalIgnoreCase));
        }
        // (Logic for VidPid detection can remain here if you use it, shortened for brevity)

        if (deviceToConnect == null) return false;

        // Avoid reconnecting if already connected
        if (_activePorts.ContainsKey(deviceToConnect.PortName)) return true;

        try
        {
            // USE THE PASSED BAUD RATE HERE
            var serialPort = new SerialPort(deviceToConnect.PortName, baudRate, Parity.None, 8, StopBits.One)
            {
                ReadTimeout = 500,
                WriteTimeout = 500,
                DtrEnable = true
            };
            serialPort.Open();

            if (serialPort.IsOpen)
            {
                _activePorts.Add(deviceToConnect.PortName, serialPort);
                return true;
            }
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Failed to open port {deviceToConnect.PortName}: {ex.Message}");
        }
        return false;
    }


    // Disconnects from a single, specified port.
    public void Disconnect(string portName)
    {
        if (_activePorts.TryGetValue(portName, out SerialPort port))
        {
            try
            {
                if (port.IsOpen)
                {
                    port.Close();
                }
                port.Dispose();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error closing port {portName}: {ex.Message}");
            }
            _activePorts.Remove(portName);
        }
    }

    // Closes all active serial port connections.
    public void DisconnectAll()
    {
        // Copy keys to a new list to avoid issues with modifying the collection while iterating
        foreach (var portName in _activePorts.Keys.ToList())
        {
            Disconnect(portName);
        }
    }


    // Sends a string of data to all currently connected devices.
    public void SendData(string data)
    {
        if (!IsConnected) return;

        List<string> failedPorts = new List<string>();

        foreach (var portEntry in _activePorts)
        {
            try
            {
                // Use WriteLine to automatically append the required '\n' character
                portEntry.Value.WriteLine(data);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Failed to send data to {portEntry.Key} (may be disconnected): {ex.Message}");
                // Mark this port for removal if it fails (e.g., unplugged during operation)
                failedPorts.Add(portEntry.Key);
            }
        }

        // Clean up any connections that failed
        foreach (var portName in failedPorts)
        {
            Disconnect(portName);
        }
    }

    // --- Helper methods for Form1 UI ---
    public bool IsPortConnected(string portName) => _activePorts.ContainsKey(portName);
    public string GetActivePortNames() => string.Join(", ", _activePorts.Keys);


    // Disposes of all managed resources, ensuring all ports are closed.
    public void Dispose()
    {
        DisconnectAll();
    }
}











