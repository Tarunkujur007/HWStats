using System;
using System.Drawing;
using System.Windows.Forms;

namespace HWStats
{
    public partial class SettingsForm : Form
    {
        // UI Controls
        private ComboBox cboBaudRate;
        private NumericUpDown numRefreshInterval;
        private TextBox txtCustomMessage;
        private Button btnSave;
        private Button btnCancel;

        public SettingsForm()
        {
            InitializeComponentCustom();
            LoadCurrentSettings();
        }

        private void LoadCurrentSettings()
        {
            // 1. Load Baud Rate
            string currentBaud = SettingsManager.CurrentSettings.BaudRate.ToString();
            if (cboBaudRate.Items.Contains(currentBaud))
                cboBaudRate.SelectedItem = currentBaud;
            else
                cboBaudRate.Text = "115200";

            // 2. Load Interval
            int interval = SettingsManager.CurrentSettings.RefreshInterval;
            numRefreshInterval.Value = interval < 100 ? 100 : interval;

            // 3. Load Custom Message
            txtCustomMessage.Text = SettingsManager.CurrentSettings.CustomMessage;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Save to SettingsManager
            if (int.TryParse(cboBaudRate.Text, out int baud))
                SettingsManager.CurrentSettings.BaudRate = baud;

            SettingsManager.CurrentSettings.RefreshInterval = (int)numRefreshInterval.Value;
            SettingsManager.CurrentSettings.CustomMessage = txtCustomMessage.Text;

            SettingsManager.Save(); // Write to Config.ini

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void InitializeComponentCustom()
        {
            // Reduced height since checkbox is gone
            this.Size = new Size(350, 240);
            this.Text = "Settings";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Labels
            Label lblBaud = new Label { Text = "Baud Rate:", Location = new Point(20, 20), AutoSize = true };
            Label lblInterval = new Label { Text = "Refresh (ms):", Location = new Point(20, 60), AutoSize = true };
            Label lblMsg = new Label { Text = "Custom Text:", Location = new Point(20, 100), AutoSize = true };
            Label lblHint = new Label { Text = "Starts with # automatically", ForeColor = Color.Gray, Location = new Point(120, 125), AutoSize = true, Font = new Font(this.Font.FontFamily, 8) };

            // Controls
            cboBaudRate = new ComboBox { Location = new Point(120, 17), Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cboBaudRate.Items.AddRange(new object[] { "9600", "19200", "38400", "57600", "115200", "230400", "921600" });

            numRefreshInterval = new NumericUpDown { Location = new Point(120, 58), Width = 150, Minimum = 100, Maximum = 60000 };

            txtCustomMessage = new TextBox { Location = new Point(120, 97), Width = 150 };

            // Buttons (Moved up since checkbox is gone)
            btnSave = new Button { Text = "Save", Location = new Point(150, 160), DialogResult = DialogResult.OK };
            btnSave.Click += btnSave_Click;

            btnCancel = new Button { Text = "Cancel", Location = new Point(240, 160), DialogResult = DialogResult.Cancel };

            this.Controls.AddRange(new Control[] { lblBaud, cboBaudRate, lblInterval, numRefreshInterval, lblMsg, txtCustomMessage, lblHint, btnSave, btnCancel });
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsForm));
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SettingsForm";
            this.ResumeLayout(false);

        }
    }
}