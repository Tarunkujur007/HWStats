using System;
using System.Runtime.InteropServices;

namespace HWStats
{
    internal static class UsbDeviceNotifier
    {
        public const int WmDevicechange = 0x0219;
        private const int DbtDevtypDeviceinterface = 5;
        private static readonly Guid GuidDevinterfaceUSBDevice = new Guid("A5DCBF10-6530-11D2-901F-00C04FB951ED");

        public static void RegisterUsbDeviceNotification(IntPtr windowHandle)
        {
            var dbi = new DEV_BROADCAST_DEVICEINTERFACE
            {
                dbcc_devicetype = DbtDevtypDeviceinterface,
                dbcc_classguid = GuidDevinterfaceUSBDevice,
            };
            dbi.dbcc_size = Marshal.SizeOf(dbi);
            IntPtr buffer = Marshal.AllocHGlobal(dbi.dbcc_size);
            Marshal.StructureToPtr(dbi, buffer, true);
            RegisterDeviceNotification(windowHandle, buffer, 0);
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr RegisterDeviceNotification(IntPtr recipient, IntPtr notificationFilter, int flags);
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    internal struct DEV_BROADCAST_DEVICEINTERFACE
    {
        public int dbcc_size;
        public int dbcc_devicetype;
        public int dbcc_reserved;
        public Guid dbcc_classguid;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 255)]
        public string dbcc_name;
    }
}