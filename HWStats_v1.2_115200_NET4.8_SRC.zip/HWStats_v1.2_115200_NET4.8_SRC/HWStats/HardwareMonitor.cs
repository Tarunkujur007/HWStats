using LibreHardwareMonitor.Hardware;
using System;
using System.Collections.Generic;
using System.Diagnostics;

public class StorageDevice
{
    public string Name { get; set; }
    public int Temperature { get; set; }
    public int UsedSpace { get; set; }
}

public class HardwareMonitor
{
    private readonly Computer _computer;
    public string CpuName { get; private set; }
    public string GpuName { get; private set; }
    public int CpuTemp { get; private set; }
    public int CpuLoad { get; private set; }
    public float CpuPower { get; private set; }
    public int CpuClock { get; private set; }
    public int GpuTemp { get; private set; }
    public int GpuLoad { get; private set; }
    public float GpuPower { get; private set; }
    public int GpuClock { get; private set; }
    public float RamUsed { get; private set; }
    public float RamAvailable { get; private set; }
    public int RamLoad { get; private set; }
    public List<StorageDevice> StorageDevices { get; private set; }
    public float DownloadSpeed { get; private set; }
    public float UploadSpeed { get; private set; }
    public float VrmTemp { get; private set; }
    public float CmosVoltage { get; private set; }
    public int CpuFanSpeed { get; private set; }
    public int CpuFanLoad { get; private set; }
    public int CpuPumpSpeed { get; private set; }
    public int GpuFanSpeed { get; private set; }
    public int GpuFanLoad { get; private set; }
    public int VirtualMemoryLoad { get; private set; }
    public float VirtualMemoryUsed { get; private set; }
    public float VirtualMemoryAvailable { get; private set; }
    public float VramTotal { get; private set; }
    public float VramUsed { get; private set; }
    public int VramLoad { get; private set; }

    public HardwareMonitor()
    {
        StorageDevices = new List<StorageDevice>();
        _computer = new Computer
        {
            IsCpuEnabled = true,
            IsGpuEnabled = true,
            IsMemoryEnabled = true,
            IsMotherboardEnabled = true,
            IsStorageEnabled = true,
            IsNetworkEnabled = true,
            IsControllerEnabled = true
        };
        _computer.Open();
    }

    public void Update()
    {
        StorageDevices.Clear();
        VrmTemp = 0; CmosVoltage = 0; CpuFanSpeed = 0; CpuFanLoad = 0; CpuPumpSpeed = 0;
        RamUsed = 0; RamAvailable = 0; RamLoad = 0; GpuFanSpeed = 0; GpuFanLoad = 0;
        VramTotal = 0; VramUsed = 0; VramLoad = 0; CpuTemp = 0; GpuPower = 0;
        int maxCpuClock = 0;

        foreach (var hardware in _computer.Hardware)
        {
            hardware.Update();
            if (hardware.HardwareType == HardwareType.Cpu) CpuName = hardware.Name;
            if (hardware.HardwareType == HardwareType.GpuNvidia || hardware.HardwareType == HardwareType.GpuAmd) GpuName = hardware.Name;

            ProcessSensors(hardware, ref maxCpuClock);

            foreach (var subHardware in hardware.SubHardware)
            {
                subHardware.Update();
                ProcessSensors(subHardware, ref maxCpuClock);
            }
        }
        if (maxCpuClock > 0) CpuClock = maxCpuClock;
    }

    private void ProcessSensors(IHardware hardware, ref int maxCpuClock)
    {
        if (hardware.HardwareType == HardwareType.Storage)
        {
            var drive = new StorageDevice { Name = hardware.Name };
            foreach (var sensor in hardware.Sensors)
            {
                if (!sensor.Value.HasValue) continue;
                if (sensor.SensorType == SensorType.Temperature) drive.Temperature = (int)sensor.Value.Value;
                if (sensor.SensorType == SensorType.Load && sensor.Name == "Used Space") drive.UsedSpace = (int)sensor.Value.Value;
            }
            StorageDevices.Add(drive);
        }

        foreach (var sensor in hardware.Sensors)
        {
            if (!sensor.Value.HasValue) continue;

            if (hardware.HardwareType == HardwareType.Motherboard || hardware.HardwareType == HardwareType.SuperIO)
            {
                if (sensor.Name == "CPU Temperature" && sensor.SensorType == SensorType.Temperature) CpuTemp = (int)sensor.Value.Value;
                if (sensor.Name == "VRM MOS" && sensor.SensorType == SensorType.Temperature) VrmTemp = sensor.Value.Value;
                if (sensor.Name == "CMOS Battery" && sensor.SensorType == SensorType.Voltage) CmosVoltage = sensor.Value.Value;
                if (sensor.Name == "CPU Fan" && sensor.SensorType == SensorType.Fan) CpuFanSpeed = (int)sensor.Value.Value;
                if (sensor.Name == "CPU Fan" && sensor.SensorType == SensorType.Control) CpuFanLoad = (int)sensor.Value.Value;
                if (sensor.Name == "Pump Fan" && sensor.SensorType == SensorType.Fan) CpuPumpSpeed = (int)sensor.Value.Value;
            }

            if (hardware.HardwareType == HardwareType.Cpu)
            {
                if (sensor.Name == "CPU Package" && sensor.SensorType == SensorType.Temperature) CpuTemp = (int)sensor.Value.Value;
                if (sensor.Name == "CPU Total" && sensor.SensorType == SensorType.Load) CpuLoad = (int)sensor.Value.Value;
                if (sensor.Name == "CPU Package" && sensor.SensorType == SensorType.Power) CpuPower = (int)sensor.Value.Value;
                if (sensor.Name.Contains("CPU Core") && sensor.SensorType == SensorType.Clock && sensor.Value.Value > maxCpuClock) maxCpuClock = (int)sensor.Value.Value;
            }

            if (hardware.HardwareType == HardwareType.GpuNvidia || hardware.HardwareType == HardwareType.GpuAmd)
            {
                if (sensor.Name == "GPU Core" && sensor.SensorType == SensorType.Temperature) GpuTemp = (int)sensor.Value.Value;
                if (sensor.Name == "GPU Core" && sensor.SensorType == SensorType.Load) GpuLoad = (int)sensor.Value.Value;
                if (sensor.Name == "GPU Package" && sensor.SensorType == SensorType.Power) GpuPower = (int)sensor.Value.Value;
                if (sensor.Name == "GPU Core" && sensor.SensorType == SensorType.Clock) GpuClock = (int)sensor.Value.Value;
                if (sensor.Name.Contains("GPU Fan") && sensor.SensorType == SensorType.Fan && GpuFanSpeed == 0) GpuFanSpeed = (int)sensor.Value.Value;
                if (sensor.Name.Contains("GPU Fan") && sensor.SensorType == SensorType.Control && GpuFanLoad == 0) GpuFanLoad = (int)sensor.Value.Value;
                if (sensor.Name == "GPU Memory" && sensor.SensorType == SensorType.Load) VramLoad = (int)sensor.Value.Value;
                if (sensor.Name == "GPU Memory Total" && sensor.SensorType == SensorType.SmallData) VramTotal = sensor.Value.Value / 1024;
                if (sensor.Name == "D3D Dedicated Memory Used" && sensor.SensorType == SensorType.SmallData) VramUsed = sensor.Value.Value / 1024;
            }

            if (hardware.HardwareType == HardwareType.Memory)
            {
                if (sensor.Name == "Memory" && sensor.SensorType == SensorType.Load) RamLoad = (int)sensor.Value.Value;
                if (sensor.Name == "Memory Used" && sensor.SensorType == SensorType.Data) RamUsed = sensor.Value.Value;
                if (sensor.Name == "Memory Available" && sensor.SensorType == SensorType.Data) RamAvailable = sensor.Value.Value;
                if (sensor.Name == "Virtual Memory" && sensor.SensorType == SensorType.Load) VirtualMemoryLoad = (int)sensor.Value.Value;
                if (sensor.Name == "Virtual Memory Used" && sensor.SensorType == SensorType.Data) VirtualMemoryUsed = sensor.Value.Value;
                if (sensor.Name == "Virtual Memory Available" && sensor.SensorType == SensorType.Data) VirtualMemoryAvailable = sensor.Value.Value;
            }

            if (hardware.HardwareType == HardwareType.Network)
            {
                if (sensor.SensorType == SensorType.Throughput)
                {
                    if (sensor.Name.Contains("Download")) DownloadSpeed = sensor.Value.Value * 8 / 1024 / 1024;
                    if (sensor.Name.Contains("Upload")) UploadSpeed = sensor.Value.Value * 8 / 1024 / 1024;
                }
            }
        }
    }

    public void Close() => _computer.Close();
}

