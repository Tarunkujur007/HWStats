using NAudio.CoreAudioApi;
using RTSSSharedMemoryNET;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class StatsProvider
{
    private readonly HardwareMonitor _hardwareMonitor;
    private readonly Queue<int> _fpsHistory = new Queue<int>();
    private readonly StringBuilder _dataStringBuilder = new StringBuilder(512);

    public int CurrentFps { get; private set; }
    public int AverageFps { get; private set; }
    public float FrameTime { get; private set; }
    public float MasterVolume { get; private set; }

    public StatsProvider(HardwareMonitor hardwareMonitor) => _hardwareMonitor = hardwareMonitor;

    public string GetFormattedDataString()
    {
        _hardwareMonitor.Update();
        UpdateFpsAndFrameTime();
        UpdateVolumeLevel();

        _dataStringBuilder.Clear();

        _dataStringBuilder.Append($"A{_hardwareMonitor.CpuTemp}|")
          .Append($"B{_hardwareMonitor.CpuLoad}|")
          .Append($"C{_hardwareMonitor.GpuTemp}|")
          .Append($"D{_hardwareMonitor.GpuLoad}|")
          .Append($"E{_hardwareMonitor.RamUsed:F1}|F{_hardwareMonitor.RamAvailable:F1}|G{_hardwareMonitor.RamLoad}|")
          .Append($"H{_hardwareMonitor.CpuPower:F1}|I{_hardwareMonitor.CpuClock}|")
          .Append($"J{_hardwareMonitor.GpuPower:F1}|K{_hardwareMonitor.GpuClock}|")
          .Append($"L{_hardwareMonitor.VramTotal:F1}|M{_hardwareMonitor.VramUsed:F1}|N{_hardwareMonitor.VramLoad}|")
          .Append($"O{CurrentFps}|P{AverageFps}|Q{FrameTime:F2}|")
          .Append($"R{MasterVolume:F0}|")
          .Append($"S{_hardwareMonitor.DownloadSpeed:F1}|T{_hardwareMonitor.UploadSpeed:F1}|")
          .Append($"U{_hardwareMonitor.VirtualMemoryUsed:F1}|V{_hardwareMonitor.VirtualMemoryAvailable:F1}|W{_hardwareMonitor.VirtualMemoryLoad}|")
          .Append($"X{_hardwareMonitor.VrmTemp:F0}|Y{_hardwareMonitor.CmosVoltage:F2}|")
          .Append($"Z{_hardwareMonitor.CpuFanSpeed}|a{_hardwareMonitor.CpuFanLoad}|")
          .Append($"b{_hardwareMonitor.GpuFanSpeed}|c{_hardwareMonitor.GpuFanLoad}|")
          .Append($"d{_hardwareMonitor.CpuPumpSpeed}|");

        // This now loops through the list of storage devices to append all their data.
        for (int i = 0; i < _hardwareMonitor.StorageDevices.Count; i++)
        {
            var drive = _hardwareMonitor.StorageDevices[i];
            // The data format uses an index 'i' to create unique keys for each drive.
            _dataStringBuilder.Append($"|e{i}{drive.Temperature}|f{i}{drive.UsedSpace}");
        }

        _dataStringBuilder.Append($"|g{DateTime.Now:hh:mm tt}|h{DateTime.Now:ddd dd.MM.yy}|")
          .Append($"i{_hardwareMonitor.CpuName}|j{_hardwareMonitor.GpuName}|");

        return _dataStringBuilder.ToString();
    }

    private void UpdateFpsAndFrameTime()
    {
        try
        {
            var appEntries = OSD.GetAppEntries();
            if (appEntries.Any())
            {
                var activeApp = appEntries.OrderByDescending(x => x.InstantaneousFrames).FirstOrDefault();
                if (activeApp != null && activeApp.InstantaneousFrames > 0)
                {
                    int rawFps = (int)Math.Round((double)activeApp.InstantaneousFrames);
                    CurrentFps = Math.Max(0, rawFps - 1);
                    FrameTime = (float)activeApp.InstantaneousFrameTime.TotalMilliseconds;
                    _fpsHistory.Enqueue(rawFps);
                    while (_fpsHistory.Count > 10) _fpsHistory.Dequeue();
                    if (_fpsHistory.Count > 0)
                    {
                        int rawAverageFps = (int)Math.Round(_fpsHistory.Average());
                        AverageFps = Math.Max(0, rawAverageFps - 1);
                    }
                }
                else { CurrentFps = 0; AverageFps = 0; FrameTime = 0; _fpsHistory.Clear(); }
            }
            else { CurrentFps = 0; AverageFps = 0; FrameTime = 0; _fpsHistory.Clear(); }
        }
        catch { CurrentFps = 0; AverageFps = 0; FrameTime = 0; _fpsHistory.Clear(); }
    }

    private void UpdateVolumeLevel()
    {
        try
        {
            using (var enumerator = new MMDeviceEnumerator())
            using (var device = enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia))
            {
                MasterVolume = device.AudioEndpointVolume.MasterVolumeLevelScalar * 100;
            }
        }
        catch { /* Fails silently */ }
    }
}

